Francesca - a chess playing program
===================================

(c) T.P.King 1991 - 2000

Release History
===============

Release 0.78    April 2000, initial Winboard public release
Release 0.80    June 2000, slight performance and eval. tweaks. Support for
		larger opening books, initial support for Winboard
		incremental clock (note the incremental clock support is
		simplistic and not well tested. It is likely that Francesca
		plays weaker with the incremental clock option). Supplied
		with a larger opening book.
Release 0.80a   As 0.80, but compiled to use 32MB RAM, not 16MB!
Release 0.81    Slight tweak to lazy eval. and forward pruning parameters.
		Test scores remain similar to 0.80, but a serier of 106 blitz
		games against various opponents, hints at a 20-30 ELO increase.
Release 0.90    WMCCC 2000 (London) version. Eval tweaks, which extensive testing
		has shown to be beneficial. Compiled to run in under 16MB, to 
		enable as many people as possible to run the engine.

Experimental    Significant knowledge added to Francesca, resulting in a slower
Release, aka    program, but one which plays interesting chess.
M.A.D 0.01      M.A.D (Manic, Agressive, Dynamic)
		Whether this version is stronger than 0.90 is unknown.

Francesca       Extensive testing showed that Francesca M.A.D 0.01 was indeed
M.A.D 0.03      stronger than 0.90 at long time controls (by about 40 ELO, I estimate).
		M.A.D 0.03 incorporates a new book format, which stores book
		information in a more compact fashion. The book which was
		used by Francesca at the 2000 WMCCC, London is bundled in this
		release. This book contains about 50,000 moves.
		Also new is an elementary "learning" feature, designed 
		to encourage Francesca not to repeat games she loses.

Francesca       New, improved book. Slight tweaks to tree search. Now we just do a
M.A.D 0.04	null move around (beta, beta-1), looking for beta cutoffs. Better 
		reporting of the PV incorporated. Current estimate indicates that
		0.04 is over 25 ELO better than 0.03, and over 60 ELO better than
		v0.90.


Disclaimer
==========

Francesca is a chess playing program. It has been
developed in my spare time over the last nine years, and is
still in a very "rough and ready" form. Note that it comes
on an "as is" basis, with no guarantees whatsoever. If it 
breaks your computer, or does not function as you would like it 
to, tough!                     

Copyright
=========

This Winboard release of Francesca is copyrighted by the author,
but under terms that allow free distribution for non-commercial 
purposes. 

You are free to distribute the files which comprise this release,
for non-commercial purposes.

System Requirements
===================

Windows 95/98/NT with 64MB+ of RAM.

Winboard Support
================

Francesca only supports Winboard at a very simple level. You can
play games against her, but many features such as setting up a 
position, game in X etc. are not currently supported.

Hint: if you are wanting Francesca to play a series of matches
against another engine, make sure you use the /xreuse /xreuse2 
parameters with Winboard.

Limitations of freely distributable version
===========================================

Hash tables fixed at 16MB.

Author
======

Tom King,
U.K.

Email: tom_king@btinternet.com

Hey, I've spotted a weakness/ bug in Francesca
==============================================

Have you? Let me know! Drop me a line, I like to hear comments from
other computer chess enthusiasts.

