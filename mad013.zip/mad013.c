/***************************************/
/* Francesca - (C) 1991-2005 T.P.King. */
/***************************************/

/* A Chess playing program */

#include <conio.h>
/* commented out - was screwing Win32 */
#define _getch(); 

#define VERSION "M.A.D 0.12"

#ifdef WINBOARD
#include <windows.h>
#endif

#include "franchs8.h"
#include <ctype.h>
#include <stdlib.h>


#if 0
#include <pc.h>
#endif

#ifdef QMW
#include "self.c"
#include "qmwinc.c"
#endif
static void kingsafe( );
static int null[64];
static int absv[128];
static int g_root=0;
static unsigned int kd[99][99];
static int gsc=0;
static int legalf[256], legalt[256];
static int n_leg;
static int OMAX=0;
static int mvvlva[32][32];
static int hist[256][256];
static const int maxhist=16384;
static int histval[64];
static double time_used;
static double min_time;
static double max_time;
static double max_bad_time;
static double max_lose_time;
static double abs_max_time;
static double time_pot=0;
static int maxply=0;
static int lastmovef, lastmovet;
static int op_delay=30;
static int CPUpromote=0;
#ifdef WINBOARD
static int winbdmv=1;
static int ponder=1;
static int post=1;
#endif

static int lastbookmove=0;
static int MAKINGASSUMEDMOVE=0;
int incremental=1;
int moves_to_make=60;
int mins=5;

int poss[24][128][128];
int diff[256];
int cpos[64];
int *lwp, *lbp;

/* incremental clock, (winboard) */
int inc_clock_extra_secs=0;
/* store moves for both humans and computer in this array */
/* - allows us to output the moves to a file at any stage */
char gamescorec[512][8], gamescoreh[512][8];

int board_setup=0;
int cpu_to_move_first=0;
#include "setup1.c"
#include "hash15b.c"

#include "2006eval(5).c"


#include <setjmp.h>

jmp_buf mark;

static BITBOARD position[64];

static int ob();
static int checkbook();
static void storeboard();
static int occurred_before();
static void undo_last_move();
static int check_if_legal_for_black(int from, int to);
static int check_if_legal_for_white(int from, int to);    
static int check_if_legal_for_black_non_cap(int from, int to);
static int check_if_legal_for_white_non_cap(int from, int to);    
static void genlegalwhitenoncap();
static void wpawnnoncap();
static void wknightnoncap();
static void wbishopnoncap();
static void wrooknoncap();
static void wqueennoncap();
static void wkingnoncap();
static void genlegalblacknoncap();
static void bpawnnoncap();
static void bknightnoncap();
static void bbishopnoncap();
static void brooknoncap();
static void bqueennoncap();
static void bkingnoncap();

static int fastgenlwcheck();
static int fastgenlbcheck();


#ifdef CLOCKS_PER_SEC
#define CLK_TCK CLOCKS_PER_SEC
#endif



#define MAX_NORTC 0
/* don't print out search info for QUIET_PLY-1 plies - helps blitz.. */
#define QUIET_PLY 7


#ifdef WINBOARD

int mykbhit( )
{
   int i;
   static int init = 0, pipe;
   static HANDLE inh;
   DWORD dw;

   if (BACKGROUND==0)
	   return(0);

   if (!ponder)
	   return(1);

   if (1) {
    if (!init) {
      init = 1;
      inh = GetStdHandle(STD_INPUT_HANDLE);
      pipe = !GetConsoleMode(inh, &dw);
      if (!pipe) {
	SetConsoleMode(inh, dw & ~(ENABLE_MOUSE_INPUT|ENABLE_WINDOW_INPUT));
	FlushConsoleInputBuffer(inh);
      }
    }
    if (pipe) {
      if (!PeekNamedPipe(inh, NULL, 0, NULL, &dw, NULL)) {
	return 1;
      }
      return dw;
    } else {
      GetNumberOfConsoleInputEvents(inh, &dw);
      return dw <= 1 ? 0 : dw;
    }
   }
  }
#else
#define mykbhit kbhit

#endif


void main(argv,argc)
int argv;
char * argc[];
{
   int p;
   char input [64];
#ifdef QMW
   int copy[143];
   char control[10];
   int move;


   qmwsquares();
   showtitle();
   last_poll=clock();
#else
   for (i=0; i<64; i++)
       null[i]=0;

   if ((argv>1)&&(strncmp(argc[1],"-h",1)==0))
       {
       printf("Francesca %s: a chess playing program (c) T.P.King 2002\n",VERSION);
       printf("Usage: fran [black]\n");
       exit(0);
       }

random_nos_for_pieces();
#ifdef WINBOARD
   setbuf(stdout,NULL);
   setjmp(mark);

#if DEBUG
	fprintf(stdout, "Got to the line after setjmp..");
#endif

/* update july 2005 - set the CASTLE variable to 3. We use the LSB to represent */
/* whether kingside castling is legal, the next bit to represent whether queenside */
/* castling is legal */

	g=0; BOOK=2; CASTLE=3; winbdmv=1;

   /* setbuf(stdin,NULL); */
   #endif

   read_phash_table();
   real_clear_hash_table();
   real_clear_hist_table();
   
#ifndef WINBOARD
   if (argv>1)
       {
       colour=BLACK;
       printf("Computer is to play BLACK\n");
       }
   else
       printf("Computer is to play WHITE\n");
#endif
#endif

   

/* setup array of distances - speeds up eval */
   setupdist();
/* mvvlva values */

   mvvlva[WK][BQ]=mvvlva[BK][WQ]=26900;
   mvvlva[WP][BQ]=mvvlva[BP][WQ]=27800;                  
   mvvlva[WN][BQ]=mvvlva[BN][WQ]=27600;                  
   mvvlva[WB][BQ]=mvvlva[BB][WQ]=27400;                  
   mvvlva[WR][BQ]=mvvlva[BR][WQ]=27200;                  
   mvvlva[WQ][BQ]=mvvlva[BQ][WQ]=27000;                  

   mvvlva[WK][BR]=mvvlva[BK][WR]=25700;    
   mvvlva[WP][BR]=mvvlva[BP][WR]=26600; 
   mvvlva[WN][BR]=mvvlva[BN][WR]=26400;    
   mvvlva[WB][BR]=mvvlva[BB][WR]=26200; 
   mvvlva[WR][BR]=mvvlva[BR][WR]=26000;    
   mvvlva[WQ][BR]=mvvlva[BQ][WR]=25800; 

   mvvlva[WK][BB]=mvvlva[BK][WB]=24500;    
   mvvlva[WP][BB]=mvvlva[BP][WB]=25400; 
   mvvlva[WN][BB]=mvvlva[BN][WB]=25200;    
   mvvlva[WB][BB]=mvvlva[BB][WB]=25000; 
   mvvlva[WR][BB]=mvvlva[BR][WB]=24800;    
   mvvlva[WQ][BB]=mvvlva[BQ][WB]=24600; 

   mvvlva[WK][BN]=mvvlva[BK][WN]=23300;    
   mvvlva[WP][BN]=mvvlva[BP][WN]=24200; 
   mvvlva[WN][BN]=mvvlva[BN][WN]=24000;    
   mvvlva[WB][BN]=mvvlva[BB][WN]=23800; 
   mvvlva[WR][BN]=mvvlva[BR][WN]=23600;    
   mvvlva[WQ][BN]=mvvlva[BQ][WN]=23400; 

   mvvlva[WK][BP]=mvvlva[BK][WP]=22100;    
   mvvlva[WP][BP]=mvvlva[BP][WP]=23000; 
   mvvlva[WN][BP]=mvvlva[BN][WP]=22800;    
   mvvlva[WB][BP]=mvvlva[BB][WP]=22600; 
   mvvlva[WR][BP]=mvvlva[BR][WP]=22400;    
   mvvlva[WQ][BP]=mvvlva[BQ][WP]=22200; 

   mvvlva[WK][BK]=mvvlva[BK][WK]=29000;    
   mvvlva[WP][BK]=mvvlva[BP][WK]=29000; 
   mvvlva[WN][BK]=mvvlva[BN][WK]=29000;    
   mvvlva[WB][BK]=mvvlva[BB][WK]=29000; 
   mvvlva[WR][BK]=mvvlva[BR][WK]=29000;    
   mvvlva[WQ][BK]=mvvlva[BQ][WK]=29000; 
   
   histval[0]=0;
   histval[1]=1;
   histval[2]=4;
   histval[3]=9;
   histval[4]=16;
   histval[5]=25;
   histval[6]=36;
   histval[7]=49;
   histval[8]=64;
   histval[9]=81;
   histval[10]=100;
   histval[11]=121;
   histval[12]=144;
   histval[13]=169;
   histval[14]=196;
   histval[15]=225;
   histval[16]=256;
   histval[17]=256;
   histval[18]=256;
   histval[19]=256;
   histval[20]=256;
   histval[21]=256;
   histval[22]=256;
   histval[23]=256;
   histval[24]=256;
   histval[25]=256;
   histval[26]=256;
   histval[27]=256;
   histval[28]=256;
   histval[29]=256;
   histval[30]=256;
   histval[31]=256;
   histval[32]=256;
   histval[33]=256;
   histval[34]=256;
   histval[35]=256;
   histval[36]=256;
   histval[37]=256;
   histval[38]=256;
   histval[39]=256;
   histval[40]=256;
   histval[41]=256;
   histval[42]=256;
   histval[43]=256;
   histval[44]=256;
   histval[45]=256;
   histval[46]=256;
   histval[47]=256;
   histval[48]=256;
   histval[49]=256;
   histval[50]=256;
   histval[51]=256;
   histval[52]=256;
   histval[53]=256;
   histval[54]=256;
   histval[55]=256;
   histval[56]=256;
   histval[57]=256;
   histval[58]=256;
   histval[59]=256;
   histval[60]=256;
   histval[61]=256;
   histval[62]=256;
   histval[63]=256;

   setboard();
   setposs();
   

   makebook();
   CASTLE=3; /* assume one can castle */

   showtitle();

#if DEBUG
   fprintf(stdout, "returned from showtitle..BOOK is %d\n",BOOK);
#endif

   /* setup a special position - if the user wants */
#ifndef WINBOARD
   setup_position();
#endif
   create_hash_for_board();
   setkd();
#ifdef QMW
   no_of_seconds=172;
   auto_startup(control);
   switch(control[0])
       {
       case 'w': colour=WHITE;
		 printf("Computer is to play WHITE\n");
		 break;
       case 'b': colour=BLACK;
		 printf("Computer is to play BLACK\n");
		 /* swap round */
		 p=0;
		 for (i=21; i< 99; i++)
		     {
		     copy[98-p]=b[i];
		     p++;
		     }
		 for (i=21; i<99 ;i++)
		     {
		     switch(copy[i])
			 {
			 case BR: b[i]=WR; break;
			 case BN: b[i]=WN; break;
			 case BB: b[i]=WB; break;
			 case BQ: b[i]=WQ; break;
			 case BK: b[i]=WK; break;
			 case BP: b[i]=WP; break;
			 case WR: b[i]=BR; break;
			 case WN: b[i]=BN; break;
			 case WB: b[i]=BB; break;
			 case WQ: b[i]=BQ; break;
			 case WK: b[i]=BK; break;
			 case WP: b[i]=BP; break;
			 default: b[i]=copy[i]; break;
			 }
		     }
	     break;
       default : printf("Communication error: auto_startup returned '%s'\n");
		 exit(0);
       }
#else
#ifndef WINBOARD
#ifndef WMCCC2000
   printf("\nEnter number of seconds/ move\n");

#ifdef WIN32
   _getch();
#endif

   gets(input);
   no_of_seconds=atoi(input);
#else
   op_delay=30;
   printf("\nEnter operator delay time per move in seconds (e.g. 20)\n");
   gets(input);
   op_delay=atoi(input);
   if (op_delay>30) 
	{
	op_delay=30;
	printf("%d seems a bit long. I've set the operator delay time to 30 seconds\n");
	}
   if (op_delay<5) 
	{
	op_delay=5;
	printf("%d seems a bit short. I've set the operator delay time to 5 seconds\n");
	}
   printf("Okay. Operator Delay is set to %d\n",op_delay);
   no_of_seconds=119-op_delay;
   printf("Francesca's initial thinking time (per move) is now %d\n",no_of_seconds+1);
#endif

#endif

#ifdef WINBOARD
   /* no_of_seconds=5;*/
#endif

   /* scanf("%d",&no_of_seconds); */
#endif

#ifndef WINBOARD   
   max_time=no_of_seconds;
   printf("max_time is %f\n",max_time);

   time_pot=no_of_seconds*60;
#endif

#ifdef WINBOARD
   if (inc_clock_extra_secs>0)
	{
	max_time+=inc_clock_extra_secs;
	}
#endif

#ifndef WINBOARD
   /* see if board has been setup, and it's the opponent to play */
   if ( (!board_setup&&colour==BLACK)||
	(board_setup&&colour==BLACK&&!cpu_to_move_first)||
	(board_setup&&colour==WHITE&&!cpu_to_move_first))
	{
	printboard();
#ifdef QMW
	printf("\nPlease enter your move\n");
	last_poll=clock();
	while ((auto_readmove(&move)))
	    {
	    while (((clock()-last_poll)/CLK_TCK) < POLL_INTERVAL)
		 ;
	    last_poll=clock();
	    }
	fromqmwformat(move,&humanfrom,&humanto);
	if (!islegal())
	    {
	    fprintf(stdout, "Illegal move. Exiting\n");
	    exit(0);
	    }
#else
	calcsquares();
	do_opp_legal();
	storeboard();
	while(1)
	      {
	      printf("\nPlease enter your move\n");
	      gets(input);
	      /* scanf("%s",input); */
	      fromalg(input, &humanfrom,&humanto);
	      if (is_legal())
		  {
		  break;
		  }
	      else
		  {
		  if (humanfrom)
		      printf("Illegal move.\n");
		  }
	      }
#endif
	strcpy(gamescoreh[1],toalg(humanfrom,humanto));
	makemove(humanfrom, humanto);
	printboard();
	}
#endif

#ifdef BRATKO
dobratko();
#endif

calc_time();
while (g<512)
   {
      g++;
   fprintf(stdout, "g is %d\n",g); 
#ifdef WMCCC2000
if (g>60)
    no_of_seconds=59-op_delay;
/* 10 secs per move after move 90 */
if (g>90)
    no_of_seconds=10;
#endif
      BACKGROUND=0;
      
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  start();
loop: 
      if (time_used>1)
	  printf("\nTotal Nodes = %ld NPS = %.0f\n",no,(double)no/time_used);
      else
	  printf("\nTotal Nodes = %ld\n",no);
      printf("Spare Time Pot = %f\n",time_pot);

	  calc_time();

/*
loop: printf("\a\nNodes examined = %ld \n",no);
*/
#ifdef DEBUG
      printf("move no is %d\n",g);
#endif

      if (ply1f>MACHINE_CASTLES)
	{
#ifdef QMW
	toqmwformat(&move, ply1f, ply1t);
	if (auto_makemove(move))
	    {
	    fprintf(stderr,"Communication error. Exiting\n");
	    exit(0);
	    }
#endif
	makecastle(ply1f);
	CASTLE=0;
	}
      else
	{
#ifdef QMW
	toqmwformat(&move, ply1f, ply1t);
	if (auto_makemove(move))
	    {
	    fprintf(stderr,"Communication error. Exiting\n");
	    exit(0);
	    }
#endif
    if (b[ply1f]==WK) CASTLE=0;
	if (CASTLE)
	{
    if (colour==WHITE && b[ply1f]==WR && ply1f==28) CASTLE^=1;	
    if (colour==WHITE && b[ply1f]==WR && ply1f==21) CASTLE^=2;
    if (colour==BLACK && b[ply1f]==WR && ply1f==28) CASTLE^=2;	
    if (colour==BLACK && b[ply1f]==WR && ply1f==21) CASTLE^=1;
	}

	fprintf(stdout, "CASTLE is %d\n",CASTLE);

	p=b[ply1f]; b[ply1f]=0; b[ply1t]=p;
	}
      /* check for computer queening */
      if ((p==WP)&&(ply1t>90&&ply1t<99)) {b[ply1t]=WQ; CPUpromote=1;}
      else CPUpromote=0;
#ifdef WINBOARD
	/* printboard(); */
	if (!ply1f) /* no move.. so we must have lost or stalemate */
	    {
	    if (ic[ply])
	        fprintf(stdout,"resign\n", winbdmv,toalg(ply1f,ply1t));    
	    else
		    fprintf(stdout,"1/2-1/2 {Stalemate}\n", winbdmv,toalg(ply1f,ply1t));    

#if DEBUG
	fprintf(stdout, "About to call longjmp..");
#endif
	longjmp(mark,0);
	    }
	else
	    {
	    if (CPUpromote)
		fprintf(stdout,"%d. ... %sq\n", winbdmv,toalg(ply1f,ply1t));
	    else
		fprintf(stdout,"%d. ... %s\n", winbdmv,toalg(ply1f,ply1t));
	    }
	    

	/* check for draws */
	if (g>400)
	    {
	    fprintf(stdout,"1/2-1/2 {Draw by 50 moves rule}\n", winbdmv,toalg(ply1f,ply1t));    

#if DEBUG
	fprintf(stdout, "About to call longjmp..");
#endif
	longjmp(mark,0);

	    }
	if ((occurred_before())>2)
	    {
	    fprintf(stdout,"1/2-1/2 {Draw by repetition}\n", winbdmv,toalg(ply1f,ply1t));    

#if DEBUG
	fprintf(stdout, "About to call longjmp..");
#endif
	longjmp(mark,0);
	    }
	if (deaddraw()==EXACT)
	    {
	    fprintf(stdout,"1/2-1/2 {insufficient material}\n", winbdmv,toalg(ply1f,ply1t));    

#if DEBUG
	fprintf(stdout, "About to call longjmp..");
#endif
	longjmp(mark,0);
	    }

	winbdmv++;
#else
      printf("\n>>>> My move is %s <<<<\n",toalg(ply1f,ply1t));
      /* printf("\a"); */
      printboard();
      printf(">>>> My move is %s <<<<\n\n",toalg(ply1f,ply1t));
#endif

#ifdef DEBUG
      printf("evalhit %d evalmiss %d\n",evalhit,evalmiss);
      printf("evalhash hit percent %f\n",100.0*(((double)evalhit)/((double)evalhit+(double)evalmiss)));
#endif
      lastmovef=ply1f;
      lastmovet=ply1t;

      calcsquares();
      printf("Static eval is %d\n",loudeval((BITBOARD)0,(BITBOARD)0));

      strcpy(gamescorec[g],toalg(ply1f,ply1t));

#if SOUND
      sound(600);
      delay(100);
      sound(800);
      delay(100);
      sound(900);
      delay(100);
      sound(1000);
      delay(700);
      sound(0);
#endif
      clear_hash_table();
      clear_hist_table();
      storeboard();
      create_hash_for_board();  
      /* printf("hash is %ld\n",hash_board); */
      do_opp_legal();
      BACKGROUND=1;
      MAKINGASSUMEDMOVE=1;
      makeassumedmove();
      MAKINGASSUMEDMOVE=0;
      g++;
      start();
      g--;
      if (BACKGROUND==1)
	  {
	  unmakeassumedmove();
#ifdef QMW
	  if (islegal())
	      makemove(humanfrom,humanto);
	  else
	      {
	      fprintf(stdout,"Illegal move. Exiting\n");
	      exit(0);
	      }
#else
	  while(1)
	      {
	      /* user asked to takeback move */
	      if (STOP==2)
		  {
		  printboard();
		  undo_last_move();
#ifndef WINBOARD
		  fprintf(stdout,"\nPlease enter your move\n");
#endif
		  gets(input);
		  /* scanf("%s",input); */
		  /* undo another move? */
		  if (!strcmp(input, "undo")||!strcmp(input, "UNDO")||!strcmp(input, "remove")||!strcmp(input, "REMOVE"))
		      {
		      STOP=2;
		      continue;
		      }
		  fromalg(input, &humanfrom,&humanto);
		  STOP=0;
		  continue;
		  }
	      if (is_legal())
		  {
		  makemove(humanfrom,humanto);
		  /*
		  fprintf(stdout, "g is %d\n",g);
		  strcpy(gamescoreh[g],toalg(humanfrom,humanto));
		  */
		  break;
		  }
	      else
		  {
#ifndef WINBOARD
		  if (humanfrom)
		      fprintf(stdout,"Illegal move.\n");
		  fprintf(stdout,"\nPlease enter your move\n");
#endif
		  gets(input);
		  /* scanf("%s",input); */
		  /* undo a move? */
		  if (!strcmp(input, "undo")||!strcmp(input, "UNDO")||!strcmp(input, "remove")||!strcmp(input, "REMOVE"))
		      {
		      STOP=2;
		      continue;
		      }
		  fromalg(input, &humanfrom,&humanto);
		  }
	      }
#endif
	  clear_hash_table();
	  clear_hist_table();   
	  create_hash_for_board();  
	  printboard();
	  }
      else goto loop;
   }
}

#ifdef QMW
int islegal()
{
int leg=0;

DMAX+=10;
calcsquares();
genlegalblack();
for (i=(ply<<7); i<=nb; i++)
    {
    if ((plyf[i]==humanfrom)&&(plyt[i]==humanto))
	leg=1;
    }

if (leg==0)
/* see if its a castling move */
    {
    if ((b[95]==BK)&&(b[98]==BR)&&(b[96]==0)&&(b[97]==0)&&(humanfrom==95)&&(humanto==97))
	{
	humanfrom=HUMAN_CASTLE_B_K;
	leg=1;
	}
    if ((b[95]==BK)&&(b[91]==BR)&&(b[92]==0)&&(b[93]==0)&&(b[94]==0)&&(humanfrom==95)&&(humanto==93))
	{
	humanfrom=HUMAN_CASTLE_B_Q;
	leg=1;
	}
    if ((b[94]==BK)&&(b[98]==BR)&&(b[97]==0)&&(b[96]==0)&&(b[95]==0)&&(humanfrom==94)&&(humanto==96))
	{
	humanfrom=HUMAN_CASTLE_W_Q;
	leg=1;
	}
    if ((b[94]==BK)&&(b[91]==BR)&&(b[92]==0)&&(b[93]==0)&&(humanfrom==94)&&(humanto==92))
	{
	humanfrom=HUMAN_CASTLE_W_K;
	leg=1;
	}
    }
DMAX-=10;
return(leg);
}
#endif

static void makemove(p1, p2)
int p1,p2;
{
int p;

      /* check for human queening */
      if ((b[p1]==BP)&&(p2<29)) b[p1]=promoteto;
      /* and for machine */
      if ((b[p1]==WP)&&(p2>90)) b[p1]=WQ;

      /* check for castling legality */
      if (p1==HUMAN_CASTLE_B_K)
      {
	b[95]=b[98]=0;
	b[97]=BK;
	b[96]=BR;
	return;
      }
      if (p1==HUMAN_CASTLE_B_Q)
      {
	b[91]=b[95]=0;
	b[94]=BR;
	b[93]=BK;
	return;
      }
      if (p1==HUMAN_CASTLE_W_K)
      {
	b[94]=b[91]=0;
	b[93]=BR; b[92]=BK;
	return;
      }
      if (p1==HUMAN_CASTLE_W_Q)
      {
	b[94]=b[98]=0;
	b[95]=BR; b[96]=BK;
	return;
      }

      if (p1>MACHINE_CASTLES)
	{
	makecastle(p1);
	CASTLE=0;
	return;
	}

      p=b[p1];
      b[p1]=0;
      b[p2]=p;
}


/* decode user's input. This will either be a move, 'exit' or 'help' */
static void fromalg(char * input,int *p1, int *p2)
{
/* zap leading spaces */
while (*input==' '&&input!='\0')
    {
    input++;
    }

if (strncmp(input,"exit",4)==0||strncmp(input,"quit",4)==0)
    {
    /* user wants to quit. so write game score to a file, then exit..*/
    FILE *fp;

    printf("Writing moves to file \"chess.txt\"\n");

    fp=fopen("chess.txt","w");
    if (fp==NULL)
	{
	fprintf(stderr, "Couldn't open file \"chess.txt\" for writing!\n");
	exit(0);
	}
    fprintf(fp,"[Event \"\"]\n");
    fprintf(fp,"[Site  \"\"]\n");
    fprintf(fp,"[Date \"\"]\n");
    if (colour==WHITE)
	{
	fprintf(fp,"[White \"Francesca v%s\"]\n",VERSION);
	fprintf(fp,"[Black \"\"]\n");
	}
    else
	{
	fprintf(fp,"[White \"\"]\n");
	fprintf(fp,"[Black \"Francesca v%s\"]\n",VERSION);
	}
    fprintf(fp,"[Result \"\"]\n");
    for (i=1; i<=g; i++)
	{
	if (colour==BLACK)
	    fprintf(fp, "%d. %s %s\n",i,gamescoreh[i], gamescorec[i]);
	else
	    fprintf(fp, "%d. %s %s\n",i,gamescorec[i], gamescoreh[i]);            
	}
    fclose(fp);
    exit(0);
    }

if (strncmp(input,"help",4)==0)
    {
    fprintf(stdout,"\nEnter moves in algebraic notation, e.g e2e4\n");
    fprintf(stdout,"For kingside castling, enter O-O\n");
    fprintf(stdout,"For queenside castling, enter O-O-O\n\n");
    /* fprintf(stdout,"To redisplay the board, enter board\n\n"); */
    fprintf(stdout,"To quit game, enter exit. Francesca will then write the\n");
    fprintf(stdout,"current game into a file, \"chess.txt\", then exit\n");
    *p1=0;
    *p2=0;
    return;
    }

/*
if (strncmp(input, "board", 5)==0)
    {
    int t=BACKGROUND;

    BACKGROUND=0;
    printboard();
    BACKGROUND=1;
    *p1=0;
    *p2=0;
    return;
    }
*/


#ifdef WINBOARD

if (strncmp(input,"new",3)==0)
{
#if DEBUG
	fprintf(stdout, "About to call longjmp..");
#endif
	longjmp(mark,0);
}

if (strncmp(input, "time",4)==0)
{
char *p;
int time_from_winboard;

	p=&input[0];
	p+=5;
	sscanf(p,"%d",&time_from_winboard);
	time_pot=(double)time_from_winboard;
	time_pot/=100;

#if DEBUG
	fprintf(stdout, "got time command. set time_pot to %f\n",time_pot);
#endif

calc_time();

}

if (strncmp(input,"easy",4)==0)
    {
	ponder=0;
    }

if (strncmp(input,"hard",4)==0)
    {
	ponder=1;
    }

#if 0
if (strncmp(input,"post",4)==0)
    {
	ponder=0;
    }

if (strncmp(input,"nopost",6)==0)
    {
	ponder=1;
    }
#endif

/* castle? */
if (strncmp(input,"e1c1",4)==0)
{
	for (i=0; i<=n_leg; i++)
    {
    if (legalf[i]==4)
		strcpy(input,"ooo");
    }
}

if (strncmp(input,"e1g1",4)==0)
{
	for (i=0; i<=n_leg; i++)
    {
    if (legalf[i]==3)
		strcpy(input,"oo");
    }
}

if (strncmp(input,"e8g8",4)==0)
{
	for (i=0; i<=n_leg; i++)
    {
    if (legalf[i]==1)
		strcpy(input,"oo");
    }
}

if (strncmp(input,"e8c8",4)==0)
{
	for (i=0; i<=n_leg; i++)
    {
    if (legalf[i]==2)
		strcpy(input,"ooo");
    }
}
#endif

if (strncmp(input,"ooo",3)==0||strncmp(input,"o-o-o",5)==0||
    strncmp(input,"OOO",3)==0||strncmp(input,"O-O-O",5)==0)
   {
   *p1=2+(2*(colour==BLACK));
   *p2=2+(2*(colour==BLACK));
   return;
   }
else if (strncmp(input,"oo",2)==0||strncmp(input,"o-o",5)==0||
	 strncmp(input,"OO",2)==0||strncmp(input,"O-O",5)==0)
   {
   *p1=1+(2*(colour==BLACK));
   *p2=1+(2*(colour==BLACK));
   return;
   }

if (colour==WHITE)
   {
   *p1=((input[1]-'1'+1)*10)+(input[0]-'a'+1)+10;
   *p2=((input[3]-'1'+1)*10)+(input[2]-'a'+1)+10;
   }
else
   {
   *p1=(('9'-input[1])*10)+('h'-input[0]+1)+10;
   *p2=(('9'-input[3])*10)+('h'-input[2]+1)+10;
   }

/* a promotion */
promoteto=BQ;
if (input[4]!=NULL&&input[4]&&input[4]!='\n'&&input[4]!='\0')
   {
   if (input[4]=='q'||input[4]=='Q')
       promoteto=BQ;
   if (input[4]=='r'||input[4]=='R')
       promoteto=BR;
   if (input[4]=='b'||input[4]=='B')
       promoteto=BB;
   if (input[4]=='n'||input[4]=='N')
       promoteto=BN;
   }
}

static char * toalg(from, to)
int from, to;
{
static char result[10], temp[10];

if (!from)
    {
    return("?");
    }

/* human entered O-O ? */
if (from==1)  
    {
#ifdef WINBOARD
	sprintf(result,"e8g8");
#else
    sprintf(result,"O-O");
#endif
    return (result);
    }

/* human entered O-O-O ? */
if (from==2)  
    {
#ifdef WINBOARD
	sprintf(result,"e8c8");
#else
    sprintf(result,"O-O-O");
#endif
    return (result);
    }

/* human entered O-O ? */
if (from==3)  
    {
#ifdef WINBOARD
	sprintf(result,"e1g1");
#else
    sprintf(result,"O-O");
#endif
    return (result);
    }

/* human entered O-O-O ? */
if (from==4)  
    {
#ifdef WINBOARD
	sprintf(result,"e1c1");
#else
    sprintf(result,"O-O-O");
#endif
    return (result);
    }


if (from>MACHINE_CASTLES)
    {
#ifdef WINBOARD
    if (from==MACHINE_CASTLE_W_K) sprintf(result,"e1g1");
    if (from==MACHINE_CASTLE_B_K) sprintf(result,"e8g8");
    if (from==MACHINE_CASTLE_W_Q) sprintf(result,"e1c1");
    if (from==MACHINE_CASTLE_B_Q) sprintf(result,"e8c8");
#else
	if (from==MACHINE_CASTLE_W_K) sprintf(result,"O-O");
    if (from==MACHINE_CASTLE_B_K) sprintf(result,"O-O");
    if (from==MACHINE_CASTLE_W_Q) sprintf(result,"O-O-O");
    if (from==MACHINE_CASTLE_B_Q) sprintf(result,"O-O-O");
#endif
    }
else
    {
    switch (colour)
	{
	case(WHITE):
	    sprintf(temp,"%d%d",from,to);
	    result[1]=temp[0]-'1'+'1'-1;
	    result[0]=temp[1]-'1'+'a';
	    result[3]=temp[2]-'1'+'1'-1;
	    result[2]=temp[3]-'1'+'a';
	    result[4]='\0';
	    break;
	case(BLACK):
	    sprintf(temp,"%d%d",from,to);
	    result[1]='9'-(temp[0]-'1');
	    result[0]='h'-(temp[1]-'1');
	    result[3]='9'-(temp[2]-'1');
	    result[2]='h'-(temp[3]-'1');
	    result[4]='\0';
	    break;
	}
    }
return (result);
}

static void setboard()
{
char temp[10];

for (i=0;i<144;i++)
{
   b[i]=OFF_BOARD;
}
b[21]=WR;b[28]=WR;
b[22]=WN;b[27]=WN;
b[23]=WB;b[26]=WB;
b[24]=WQ;b[25]=WK;

b[91]=BR;b[98]=BR;
b[92]=BN;b[97]=BN;
b[93]=BB;b[96]=BB;
b[94]=BQ;b[95]=BK;

if (colour==BLACK)
    {
    b[24]=WK; b[25]=WQ;
    b[94]=BK; b[95]=BQ;
    }

for(i=0;i<8;i++)
{
   b[i+31]=WP;
   b[i+81]=BP;
   b[i+41]=0;
   b[i+51]=0;
   b[i+61]=0;
   b[i+71]=0;
}

b[MACHINE_CASTLE_W_K]=0;
b[MACHINE_CASTLE_B_K]=0;

v[WR]=685;v[WN]=425;v[WB]=435;v[WQ]=1240;v[WK]=20000;v[WP]=105;
v[BP]=105;v[BR]=685;v[BN]=425;v[BB]=435;v[BQ]=1240;v[BK]=10000;

absv[WR]=500;absv[WN]=300;absv[WB]=300;absv[WQ]=900;absv[WK]=20000;absv[WP]=100;
absv[BP]=100;absv[BR]=500;absv[BN]=300;absv[BB]=300;absv[BQ]=900;absv[BK]=10000;

/* Encourage centralisation of pieces */

strcpy(temp,"00000000");
for (i=0;i<strlen(temp);i++)
    {
    c[21+i]=temp[i]-'0';
    c[91+i]=temp[i]-'0';
    }
strcpy(temp,"00000000");
for (i=0;i<strlen(temp);i++)
    {
    c[31+i]=temp[i]-'0';
    c[81+i]=temp[i]-'0';
    }
strcpy(temp,"00111100");
for (i=0;i<strlen(temp);i++)
    {
    c[41+i]=temp[i]-'0';
    c[71+i]=temp[i]-'0';
    }
strcpy(temp,"00144100");
for (i=0;i<strlen(temp);i++)
    {
    c[51+i]=temp[i]-'0';
    c[61+i]=temp[i]-'0';
    }
c[0]=0;
}

setposs()
{
int j;
for (i=21; i<99; i++)
    {
    j=i+21;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i+12;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i-8;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i-19;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i-21;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i-12;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i+8;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}
    j=i+19;
    if (b[j]!=OFF_BOARD)
	{
	poss[WN][i][j]=1;
	poss[BN][i][j]=1;
	}

    for (j=i+10; j<99 & b[j]!=OFF_BOARD; j+=10)
	{
	poss[WR][i][j]=1;
	poss[BR][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i+10)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    }
	}
    for (j=i-10; j>20 & b[j]!=OFF_BOARD; j-=10)
	{
	poss[WR][i][j]=1;
	poss[BR][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i-10)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    }
	}
    for (j=i-1; j>20 & b[j]!=OFF_BOARD; j--)
	{
	poss[WR][i][j]=1;
	poss[BR][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i-1)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    }

	}
    for (j=i+1; j<99 & b[j]!=OFF_BOARD; j++)
	{
	poss[WR][i][j]=1;
	poss[BR][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i+1)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    }
	}
    
    for (j=i+9; j<99 & b[j]!=OFF_BOARD; j+=9)
	{
	poss[WB][i][j]=1;
	poss[BB][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i+9)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    poss[WP][i][j]=1;
	    }
	}
    for (j=i-9; j>20 & b[j]!=OFF_BOARD; j-=9)
	{
	poss[WB][i][j]=1;
	poss[BB][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i-9)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    poss[BP][i][j]=1;
	    }
	}
    for (j=i-11; j>20 & b[j]!=OFF_BOARD; j-=11)
	{
	poss[WB][i][j]=1;
	poss[BB][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i-11)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    poss[BP][i][j]=1;
	    }
	}
    for (j=i+11; j<99 & b[j]!=OFF_BOARD; j+=11)
	{
	poss[WB][i][j]=1;
	poss[BB][i][j]=1;
	poss[WQ][i][j]=1;
	poss[BQ][i][j]=1;
	if (j==i+11)
	    {
	    poss[WK][i][j]=1;
	    poss[BK][i][j]=1;
	    poss[WP][i][j]=1;
	    }
	}
    }

/* setup diff array */

diff[128+10]=10;
diff[128+20]=10;
diff[128+30]=10;
diff[128+40]=10;
diff[128+50]=10;
diff[128+60]=10;
diff[128+70]=10;

diff[128+9]=9;
diff[128+18]=9;
diff[128+27]=9;
diff[128+36]=9;
diff[128+45]=9;
diff[128+54]=9;
diff[128+63]=9;

diff[128+11]=11;
diff[128+22]=11;
diff[128+33]=11;
diff[128+44]=11;
diff[128+55]=11;
diff[128+66]=11;
diff[128+77]=11;

diff[128+1]=1;
diff[128+2]=1;
diff[128+3]=1;
diff[128+4]=1;   
diff[128+5]=1;
diff[128+6]=1;
diff[128+7]=1;

diff[128-10]=-10;
diff[128-20]=-10;
diff[128-30]=-10;
diff[128-40]=-10;
diff[128-50]=-10;
diff[128-60]=-10;
diff[128-70]=-10;

diff[128-9]=-9;
diff[128-18]=-9;
diff[128-27]=-9;
diff[128-36]=-9;
diff[128-45]=-9;
diff[128-54]=-9;
diff[128-63]=-9;

diff[128-11]=-11;
diff[128-22]=-11;
diff[128-33]=-11;
diff[128-44]=-11;
diff[128-55]=-11;
diff[128-66]=-11;
diff[128-77]=-11;

diff[128-1]=-1;
diff[128-2]=-1;
diff[128-3]=-1;
diff[128-4]=-1;
diff[128-5]=-1;
diff[128-6]=-1;
diff[128-7]=-1;


}

static void printboard( )
{
int j;
char board[256];

board[0]='\0';
for (i=100;i>=10;i=i-10)
{
   for (j=i;j<i+10;j++)
   {
      if (b[j]==OFF_BOARD) {strcat( board,"  "); continue;}
      if (b[j]==0) {strcat( board,". "); continue;}
      if (b[j]==WP) {strcat( board,"P "); continue;}
      if (b[j]==BP) {strcat( board,"p "); continue;}
      if (b[j]==WB) {strcat( board,"B "); continue;}
      if (b[j]==WQ) {strcat( board,"Q "); continue;}
      if (b[j]==WK) {strcat( board,"K "); continue;}
      if (b[j]==WR) {strcat( board,"R "); continue;}
      if (b[j]==WN) {strcat( board,"N "); continue;}
      if (b[j]==BR) {strcat( board,"r "); continue;}
      if (b[j]==BN) {strcat( board,"n "); continue;}
      if (b[j]==BB) {strcat( board,"b "); continue;}
      if (b[j]==BQ) {strcat( board,"q "); continue;}
      if (b[j]==BK) strcat( board,"k ");
   }
   strcat( board,"\n");
}
printf("%s",board);
}

static char qq=0; 

static void genlegalwhite( )
{
register int *p;
#ifdef QMW
   int move;
#endif
bch=0;
nw=(ply<<7);

for (p=&wsq[0];(p!=lwp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     if (b[z]==WP) {wpawn();}
     else
     if (b[z]==WR) {wrook();}
     else
     if (b[z]==WN) {wknight();}
     else
     if (b[z]==WB) {wbishop();}
     else
     if (b[z]==WQ) {wqueen();}
     else
     if (b[z]==WK) {wking();}
if (bch) break;
}
nw--;
for (p=&wsq[0];(p!=lwp);p++)
	done[*p]=0;
}

__inline static void dowhite( )
{
/*
if (ply>=DMAX)
    printf("dowhite() called at ply>=DMAX\n");
if ((ply>=DMAX))
	return;
*/
plyf[nw]=z;
plyt[nw]=i;
o[nw]=(hist[z][i]);
nw++;
}

__inline static void takewhite( )
{
if (b[i]&START_BLACK_PIECES)
{
if (i==bkp) 
    {
    bch=1;
    }
else
    {
    plyf[nw]=z;
    plyt[nw]=i;
    o[nw]=mvvlva[b[z]][b[i]];
    nw++;
    }
}
}

static int checkwhite( )
{
if (!b[i])
	{
	dowhite();
	return(0);
	}
takewhite();
return(1);
}

static int checkwhitef( )
{
if (!b[i])
	{
	nw++;
	return(0);
	}
if (b[i]&START_BLACK_PIECES)
    {
    nw++;
    return(1);
    }
return(1);
}

static void wpawn( )
{
i=z+11;
takewhite();
i=z+9;
takewhite();
i=z+10;
if (!b[i])
	{
	dowhite();
	}
if ((z<39)&&(b[z+10]==0))
{
i=z+20;
if (!b[i]&&(b[i-1]!=BP&&b[i+1]!=BP)) dowhite();
}
}

static void wrook( )
{
for (i=z+10;;i+=10)
if (checkwhite()) break;

for (i=z+1;;i++)
if (checkwhite()) break;

for (i=z-1;;i--)
if (checkwhite()) break;

for (i=z-10;;i-=10)
if (checkwhite()) break;
}

static void wrook_mobility( )
{
for (i=z+10;;i+=10)
if (checkwhitef()) break;

for (i=z+1;;i++)
if (checkwhitef()) break;

for (i=z-1;;i--)
if (checkwhitef()) break;

for (i=z-10;;i-=10)
if (checkwhitef()) break;
}


static void wbishop( )
{
for(i=z+11;;i+=11)
if (checkwhite()) break;

for(i=z-9;;i-=9)
if (checkwhite()) break;

for(i=z-11;;i-=11)
if (checkwhite()) break;

for(i=z+9;;i+=9)
if (checkwhite()) break;
}

static void wbishop_mobility( )
{
for(i=z+11;;i+=11)
if (checkwhitef()) break;

for(i=z-9;;i-=9)
if (checkwhitef()) break;

for(i=z-11;;i-=11)
if (checkwhitef()) break;

for(i=z+9;;i+=9)
if (checkwhitef()) break;
}

static void wqueen( )
{
wrook();
wbishop();
}

static void wknight( )
{
i=z+8;
checkwhite();
i=z-8;
checkwhite();
i=z+12;
checkwhite();
i=z-12;
checkwhite();
i=z+19;
checkwhite();
i=z-19;
checkwhite();
i=z+21;
checkwhite();
i=z-21;
checkwhite();
}

static void wking( )
{
i=z+9;
checkwhite();
i=z+10;
checkwhite();
i=z+11;
checkwhite();
i=z+1;
checkwhite();
i=z-9;
checkwhite();
i=z-10;
checkwhite();
i=z-11;
checkwhite();
i=z-1;
checkwhite();
}


static void genlegalblack( )
{
register int *p;
wch=0;
nb=(ply<<7);

for (p=&bsq[0];(p!=lbp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     if (b[z]==BP) {bpawn();}
     else
     if (b[z]==BR) {brook();}
     else
     if (b[z]==BN) {bknight();}
     else
     if (b[z]==BB) {bbishop();}
     else
     if (b[z]==BQ) {bqueen();}
     else
     if (b[z]==BK) {bking();}
if (wch) break;
}
nb--;

for (p=&bsq[0];(p!=lbp);p++)
	done[*p]=0;
}

__inline static void doblack( )
{
/*
if (ply>=DMAX)
    printf("doblack() called at ply>=DMAX\n");
if ((ply>=DMAX))
	return;
*/
plyf[nb]=z;
plyt[nb]=i;
o[nb]=(hist[z][i]);
nb++;
#ifdef ORTC
if (ic[ply])
    {
    int fp,ep,mpf,mpt,n,t,t1; 
    BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;
    int cic=0;

    t=i;
    t1=z;
    BMAKEMOVE(nb-1);
    cic=fastgenlwcheck(bkp);
    /* cic = genlegalwhitecheck(bkp); */
    BUNMAKEMOVE(nb-1);
    z=t1;
    i=t;

    if (cic)
	nb--;
    }
#endif
}

__inline static void takeblack( )
{
if (b[i]&START_WHITE_PIECES)
{
if (i==wkp) 
    {
    wch=1;
    }
else
    {
    plyf[nb]=z;
    plyt[nb]=i;
    o[nb]=mvvlva[b[z]][b[i]];
    }
nb++;
#ifdef ORTC
if (ic[ply])
    {
    int fp,ep,mpf,mpt,t,n,t1; 
    BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;
    int cic=0;

    t=i;
    t1=z;
    BMAKEMOVE(nb-1);
    cic = fastgenlwcheck(bkp);
    BUNMAKEMOVE(nb-1);
    z=t1;
    i=t;

    if (cic)
	nb--;
    }
#endif
}
}

static int checkblack()
{
if (!b[i])
	{
	doblack();
	return(0);
	}
takeblack();
return(1);
}

static int checkblackf()
{
if (!b[i])
	{
	nb++;
	return(0);
	}
if (b[i]&START_WHITE_PIECES)
    {
    nb++;
    }
return(1);
}


static void bpawn( )
{
i=z-9;
takeblack();
i=z-11;
takeblack();
i=z-10;
if (!b[i])
	{
	doblack();
	}
if ((z>80)&&(b[z-10]==0))
{
i=z-20;
if (!b[i]) doblack();
}
}

static void brook( )
{
for (i=z+10;;i+=10)
if (checkblack()) break;

for (i=z+1;;i++)
if (checkblack()) break;

for (i=z-1;;i--)
if (checkblack()) break;

for (i=z-10;;i-=10)
if (checkblack()) break;
}

static void brook_mobility( )
{
for (i=z+10;;i+=10)
if (checkblackf()) break;

for (i=z+1;;i++)
if (checkblackf()) break;

for (i=z-1;;i--)
if (checkblackf()) break;

for (i=z-10;;i-=10)
if (checkblackf()) break;
}


static void bbishop( )
{
for (i=z+11;;i+=11)
if (checkblack()) break;

for (i=z-9;;i-=9)
if (checkblack()) break;

for (i=z-11;;i-=11)
if (checkblack()) break;

for (i=z+9;;i+=9)
if (checkblack()) break;
}

static void bbishop_mobility( )
{
for (i=z+11;;i+=11)
if (checkblackf()) break;

for (i=z-9;;i-=9)
if (checkblackf()) break;

for (i=z-11;;i-=11)
if (checkblackf()) break;

for (i=z+9;;i+=9)
if (checkblackf()) break;
}


static void bqueen( )
{
brook();
bbishop();
}

static void bknight( )
{
i=z+8;
checkblack();
i=z-8;
checkblack();
i=z+12;
checkblack();
i=z-12;
checkblack();
i=z+19;
checkblack();
i=z-19;
checkblack();
i=z+21;
checkblack();
i=z-21;
checkblack();
}

static void bking( )
{
i=z+9;
checkblack();
i=z+10;
checkblack();
i=z+11;
checkblack();
i=z+1;
checkblack();
i=z-9;
checkblack();
i=z-10;
checkblack();
i=z-11;
checkblack();
i=z-1;
checkblack();
}


static void start( )
{
     int t,n,min,max,p,fp,ep,mpf,mpt,bs;
     BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;
     char input[64];
	 char pv[512];
     int tmp;

     STOP=no=0;
     clock_start=clock();
     time_used=0;
     memset(done,0,100);
     swapoff(&bs);
     if (g>=30)
	 kingattack();
#ifdef LEARN
	 if (g-lastbookmove<32)
	 read_phash_table();
#endif
     ka[0]=0;
     ply=1;
     min=-100;
     max=100;
     DMAX=1;

     DMAX+=10;
     calcsquares();
     create_hash_for_board();




     /* !!!MAJOR FIX 24/2/98 */
     old_hash_board=hash_board;


     ic[ply]=0;
     initpos();
     /* mod - null move decision now made in search */
     for (i=0; i<64; i++)
       null[i]=0;
     sc=loudeval((BITBOARD)0,(BITBOARD)0);
     gsc=sc;

     printf("root score is %d\n",gsc+bs);

     genlegalwhite();
     DMAX-=10;

     t=nw;
     for (p=(ply<<7);p<=t;p++)
	{
	WMAKEMOVE(p);
	/* remove our piece if it's a capture - */
	/* to make captures look less favourable */
	if ((ep!=0)&&(fp!=WK)) b[plyt[p]]=0;
	/* printf("%s \n",toalg(plyf[p],plyt[p])); */
	root[p]/* + */=bs;
	/* root[p]+=gsc; */
	#if 0
	if (occurred_before())
	    {
	    /* printf("\nthis position has occured before\n"); */
	    if (bs+gsc>0)
		root[p]-=100;
	    if (bs+gsc<0)
		root[p]+=100;
	    }
	#endif
#ifdef FUDGE
if ((g==1&&colour==WHITE)||(g==1&&colour==BLACK))
    {
    int ff, ft;

    srand ((unsigned int)time(NULL)%32761);
    switch (rand()%4)
	{
	case 0: ff=31;
		ft=41;
		break;
	case 1: ff=38;
		ft=48;
		break;
	case 2: ff=34;
		ft=44;
		break;
	case 3: ff=35;
		ft=45;
		break;
	}

    if (mpf==ff&&mpt==ft)
	root[p]+=99;
    }
#endif
	/* printf("(%d) ", root[p]); */
	/* put our piece back in if we've removed it */
	b[plyt[p]]=fp;
	/* we're gonna filter out illegal root moves here */
	if (fp==WK)
	    {
	    if (mpt-1==bkp||
		mpt+1==bkp||
		mpt+10==bkp||
		mpt+9==bkp||
		mpt+11==bkp||
		mpt-9==bkp||
		mpt-10==bkp||
		mpt-11==bkp)
		    {
		    o[p]=-32000;
		    }
	    }
	if (fastgenlbcheck(wkp))
	    {
	    o[p]=-32000;
	    }
	WUNMAKEMOVE(p);
	}


    if (CASTLE)
	{
	if ((colour==WHITE)&&(CASTLE&1&&cancastle(MACHINE_CASTLE_W_K)))
		{
		wsq[30]=MACHINE_CASTLE_W_K;
		t++;
		plyt[t]=plyf[t]=MACHINE_CASTLE_W_K;
		makecastle(MACHINE_CASTLE_W_K);
		/* root[t]=30; */
		root[t]=bs;
		o[t]=root[t];
		printf("Can castle. Castling score is %d\n",root[t]);
		unmakecastle(MACHINE_CASTLE_W_K);
		}
	if ((colour==BLACK)&&(CASTLE&1&&cancastle(MACHINE_CASTLE_B_K)))
		{
		wsq[30]=MACHINE_CASTLE_B_K;
		t++;
		plyt[t]=plyf[t]=MACHINE_CASTLE_B_K;
		makecastle(MACHINE_CASTLE_B_K);
		/* root[t]=29; */
		root[t]=bs;
		o[t]=root[t];
		printf("Can castle. Castling score is %d\n",root[t]);
		unmakecastle(MACHINE_CASTLE_B_K);
		}
	if ((colour==WHITE)&&(CASTLE&2&&cancastle(MACHINE_CASTLE_W_Q)))
		{
		wsq[29]=MACHINE_CASTLE_W_Q;
		t++;
		plyt[t]=plyf[t]=MACHINE_CASTLE_W_Q;
		makecastle(MACHINE_CASTLE_W_Q);
		/* root[t]=29; */
		root[t]=bs;
		o[t]=root[t];
		printf("Can castle. Castling score is %d\n",root[t]);
		unmakecastle(MACHINE_CASTLE_W_Q);
		}
	if ((colour==BLACK)&&(CASTLE&2&&cancastle(MACHINE_CASTLE_B_Q)))
		{
		wsq[29]=MACHINE_CASTLE_B_Q;
		t++;
		plyt[t]=plyf[t]=MACHINE_CASTLE_B_Q;
		makecastle(MACHINE_CASTLE_B_Q);
		/* root[t]=30; */
		root[t]=bs;
		o[t]=root[t]; 
		printf("Can castle. Castling score is %d\n",root[t]);
		unmakecastle(MACHINE_CASTLE_B_Q);
		}
	}
     else
	printf("** (can't castle) **\n");
     rsort((ply<<7),t);
     /* printf("no of pseudo legal moves = %d\n",1+t-(ply<<7)); */
     for (i=(ply<<7); i<=t; i++)
	 if (o[i]==-32000)
	     {
	     t=i-1;
	     }
     /* printf("no of legal moves after filter = %d\n",1+t-(ply<<7)); */
     /* printf("\n"); */
     
     /* only one move, go and make it straight away..*/     
     if (!BACKGROUND && t-(ply<<7)==0)
	 {
	 printf("Only one move..making it straight away..\n");
	 #ifdef WINBOARD
	     time_pot+=inc_clock_extra_secs;
	     /* fprintf(stdout,"added an extra %d to time_pot\n",inc_clock_extra_secs);
	     fprintf(stdout,"timepot is now %f\n",time_pot); */
	 #endif
	 ply1f=plyf[(ply<<7)];
	 ply1t=plyt[(ply<<7)];
	 return;
	 }
     no=0;

     printboard();

     if (!BACKGROUND&&BOOK&&ob())
	 {
	 int legal=0;

	 for (i=(ply<<7); i<=t; i++)
	     if (ply1f==plyf[i]&&ply1t==plyt[i])
		 legal=1;

	 #ifdef WINBOARD
	     time_pot+=inc_clock_extra_secs;
	     /* fprintf(stdout,"added an extra %d to time_pot\n",inc_clock_extra_secs);
	     fprintf(stdout,"timepot is now %f\n",time_pot); */
		 time_pot-=0.2;
     #else
	     time_pot-=3;
	 #endif
	 
	 

	 if (legal)
	     return;

#if DEBUG
	 for (i=(ply<<7); i<=t; i++)
	     {
	     fprintf(stdout,"%s (%d, %d) ", toalg(ply1f, ply1t), ply1f, ply1t );
	     fprintf(stdout,"%s (%d, %d)\n", toalg(plyf[i], plyt[i]), plyf[i], plyt[i]);
	     }

	 fprintf(stdout,"Illegal move found in book: %s\n", toalg(ply1f, ply1t));
	 fprintf(stdout,"Computing move instead...\n");
#endif
	 }

     clock_start=clock();
     time_used=0;

/*   printf("hash is %ld\n",hash_board); */
     for (DMAX=2; DMAX<51; DMAX++)
     {
     int j;

     /* ensure loop never ends on pondering */
     if (BACKGROUND && DMAX>49)
	 {
	 fprintf(stdout, "Erk! Max search depth reached...\n"); 
	 humanfrom=humanto=0;
	 return;
	 /*
	 clear_hash_table(); 
	 clear_hist_table();
	 for (i=3; i<30; i++)
	     killerfrom[ply]=0;
	 DMAX=35;
	 */
	 }
     OMAX=DMAX+1;
     memset(pcf,0,(39*39));
     
/*     
     for (i=0; i<64; i++)
       for (j=0; j<64; j++)
	 pcf[i][j]=0;
*/

     nw=t;
     
     if (DMAX>2)
	{

	 sc=start_search(min,max,0);

	 /* ensure we keep time_used up to date.. */
	 /* if (clock_end>clock_start)
	 {
		 time_used+=(double)(clock_end-clock_start)/CLOCKS_PER_SEC;
		 clock_start=clock_end;
	 } */

#ifndef BRATKO
	 if (
		/* score is ok.. and we've searched for min. time, so stop searching.. */
		(!BACKGROUND && !STOP && (sc>min) && (time_used > abs_max_time||(time_used > (min_time))))||
		/* score is ok(ish).. and we've searched for alloted time, so stop */
		(0 && !BACKGROUND && !STOP && (sc>min-30 && sc>-150) && (time_used > abs_max_time||(time_used > (max_time))))||
		/* score is not great - we've dropped by 70 points or less, only stop if > max_bad_time */
		(0 && !BACKGROUND && !STOP && (sc>min-70 && sc>-250) && (time_used > abs_max_time||(time_used > (max_bad_time))))|| 
		/* score is not great - we've dropped by 250 points or less, only stop if > max_lose_time */
		(0 && !BACKGROUND && !STOP && (time_used > abs_max_time||(time_used > (max_lose_time))))
	    )
	     {                                      
	     printf("\nStopped search (early) after %f seconds\n", time_used);
		 printf("time_used %f min_time %f max_time %f\nmax_bad_time %f max_lose_time %f abs_max_time %f\n",time_used,min_time,max_time,max_bad_time,max_lose_time,abs_max_time);
	 
	 #ifdef WINBOARD
	     time_pot+=inc_clock_extra_secs;
	     /* fprintf(stdout,"added an extra %d to time_pot\n",inc_clock_extra_secs);
	     fprintf(stdout,"timepot is now %f\n",time_pot); */
	 #endif

		 time_pot-=(time_used);
		 printf("subtracted %f from time_pot\n",(time_used));
	     STOP=1;
	       if (pcf[1][1])
		   {
		   ply1f=pcf[1][1];
		   ply1t=pct[1][1];
		   }
	       break;
	     }
#endif
	}
     else
	 {
	 sc=order_root_moves(-32000,0);
	 }

     ply=1;

     if (STOP) 
	       {
#ifndef BRATKO
	       if (!BACKGROUND&&DMAX>3)
		   {
		   printf("\nStopped search after %f seconds\n", time_used);
		   printf("subtracted %f from time_pot\n",(time_used));
		   time_pot-=(time_used);

	 #ifdef WINBOARD
	     time_pot+=inc_clock_extra_secs;
	     /* fprintf(stdout,"added an extra %d to time_pot\n",inc_clock_extra_secs);
	     fprintf(stdout,"timepot is now %f\n",time_pot); */
	 #endif

		   }
#endif
	       if (pcf[1][1])
		   {
		   ply1f=pcf[1][1];
		   ply1t=pct[1][1];
		   }
	       break;
	       }
     if (DMAX>QUIET_PLY)
         printf(" score %d nodes %ld",sc,no);
#if 0
     if ((sc<=min)&&(DMAX>3))
	{
	nw=t;
	if (sc<=min)
		{
		/*
		max=sc+1; - commented out May '94 as was
		causing some redos to fail high !  */
		/* max=32000; */
		max=sc+1;
		min=-32000;
		}
	/*printf("REDoing a %d ply <%d,%d> search",DMAX,min,max);*/
	printf("\nRedoing %d ply search\n",DMAX-1);
	sc=start_search(min,max,0);
	ply=1;
	if (STOP) {
	       if (pcf[1][1])
		   {
		   ply1f=pcf[1][1];
		   ply1t=pct[1][1];
		   }
	       break;
	       }
	printf(" score %d",sc);
	}
#endif
     feedover(OMAX);
     if (DMAX>QUIET_PLY)
	 printf("\nTime %.1f secs PV: ",time_used);
     if (DMAX==1)
	{
	if (DMAX>QUIET_PLY)
	    printf("%s ",toalg((pcf[1][1]),(pct[1][1])));
	}

     if (DMAX>QUIET_PLY)
	 {
	 for (i=1;i<64;i++)
		{
		if (!pcf[1][i])
		    {
		    printf("..");
		    break;
		    }
		printf("%s ",toalg((pcf[1][i]),(pct[1][i])));
		}
	 printf("\n");
	 }

#if WINBOARD
strcpy(pv,"");
for (i=1;i<64;i++)
	{
	if (!pcf[1][i])
	    {
	    break;
	    }
	strcat(pv,toalg((pcf[1][i]),(pct[1][i])));
	strcat(pv," ");
	}
fprintf(stdout, "%d %d %.0f %d %s\n",DMAX-1,sc,(time_used*100),no,pv);
#endif

     min=sc-30;
     max=sc+30;
     ply1f=pcf[1][1]; ply1t=pct[1][1];
     if ((STOP)&&(DMAX>=4)) break;
     if (!BACKGROUND&&(abs(sc)>8000))
	 break;
    }

/* i.e. if m/c guessed wrong and examined to greatest depth */
#if 0
#ifndef QMW
if ((BACKGROUND)&&(DMAX==25))
    {
    fprintf(stdout,"\nXXXPlease enter your moveXXX\n");
    gets(input);
    /* scanf("%s",input);*/
    fromalg(input, &humanfrom,&humanto);
    }
#else
#if 0
if ((BACKGROUND)&&(DMAX==25))
    {
    int move;
    fprintf(stdout,"Machine guessed wrong. Maximum search depth reached\n");
    last_poll=clock();
	while ((auto_readmove(&move)))
	    {
	    while (((clock()-last_poll)/CLK_TCK) < POLL_INTERVAL)
		 ;
	    last_poll=clock();
	    /* sleep(POLL_INTERVAL); */
	    }
	fromqmwformat(move,&humanfrom,&humanto);
#if 0
	if (!islegal())
	    {
	    fprintf(stdout, "Illegal move. Exiting\n");
	    exit(0);
	    }
#endif
    }
#endif
#endif
#endif
}

rsort(left,right)
int left,right;
{
int last,t1,t2,t3,t4;
register int y;
if (left>=right) return;
		t1=plyf[left]; t2=plyt[left]; t3=o[left];
		t4=root[left];
		plyf[left]=plyf[(left+right)/2];
		plyt[left]=plyt[(left+right)/2];
		o[left]=o[(left+right)/2];
		root[left]=root[(left+right)/2];
		plyf[(left+right)/2]=t1;
		plyt[(left+right)/2]=t2;
		o[(left+right)/2]=t3;
		root[(left+right)/2]=t4;
last=left;
for (y=left+1;y<=right;y++)
	if (o[y]>o[left])
		{
		last++;
		t1=plyf[last]; t2=plyt[last]; t3=o[last];
		t4=root[last];
		plyf[last]=plyf[y];
		plyt[last]=plyt[y];
		o[last]=o[y];
		root[last]=root[y];
		plyf[y]=t1;
		plyt[y]=t2;
		o[y]=t3;
		root[y]=t4;
		}

		t1=plyf[left]; t2=plyt[left]; t3=o[left];
		t4=root[left];
		plyf[left]=plyf[last];
		plyt[left]=plyt[last];
		o[left]=o[last];
		root[left]=root[last];
		plyf[last]=t1;
		plyt[last]=t2;
		o[last]=t3;
		root[last]=t4;
rsort(left,last-1);
rsort(last+1,right);
}

int root_alpha;
int root_beta;

static int order_root_moves(alpha,n)
int alpha,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;
int all_moves_lose=1;

ply=1;
l=nw;

     ic[ply]=0;	
     if (fastgenlbcheck(wkp))
	    {
	    ic[ply]=1;
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    }


for (p=(ply<<7);p<=l;p++)
{
	       /* printf("\n(%d/%d) %s ", p+1-((ply<<7)),l+1-((ply<<7)),toalg(plyf[p], plyt[p])); */
	       p1=p;
	       g_root=n=root[p];
	       t=n;
	       if (plyf[p1]>MACHINE_CASTLES)
		   {
		   makecastle(plyf[p1]);
		   WMAKEMOVEC(p1);
		   create_hash_for_board(); /* update hash */
		   }
		else
		{
	       WMAKEMOVE(p1);
		}

	       /* captures first, then basic eval for root ordering */
	       n=v[ep]+eval(hash_board,pawn_hash_board);

		if (all_moves_lose&&ply<DMAX)
			if (!fastgenlbcheck(wkp))
				all_moves_lose=0;

				/* If we've searched all the required nodes,
				stop searching*/
				if (STOP)
					{
					printf("#");
					n=alpha;
					}

	       if (n>alpha) {alpha=n;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				if (!ep&&mpf<MACHINE_CASTLES)
				    {
				    (hist[mpf][mpt])+=histval[DMAX-ply];   
				    if (hist[mpf][mpt]>maxhist) clear_hist_table();
				    }

				pc(mpf,mpt);}
	       if (mpf>MACHINE_CASTLES) {unmakecastle(mpf); WUNMAKEMOVEC(p1); hash_board=old_hash_board;}
		else
		{
		WUNMAKEMOVE(p1);
		}
	       o[p1]=n;
	       if (STOP) break;
	       n=t;
	  }

#if STALEDETECT
if (all_moves_lose && !ic[ply])
    {
    /*
    if (alpha<0)
    */
	alpha=0;
    }
#endif

/* ensure our best moves goes to top of list */
for (p=(ply<<7);p<=l;p++)
    if ((killerfrom[ply]==plyf[p])&&
	(killerto[ply]==plyt[p]))
	    o[p]+=1000;

rsort((ply<<7),l);

#if 0
printf("\n");
for (i=ply<<7; i<=l; i++)
    {
    printf("%s %d %d\n",toalg(plyf[i],plyt[i]),root[i],o[i]);
    }
#endif
/* printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bBest move after search to depth %d: %s ", DMAX-1,toalg(killerfrom[ply], killerto[ply])); */
/* printf("Best move after search to depth %d: %s ", DMAX-1,toalg(killerfrom[ply], killerto[ply])); */

return(alpha);
}


static int start_search(alpha,beta,n)
int alpha,beta,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
int fail_hi=0, fail_lo=0;
int oldkf=0, oldkt=0, oldalpha=alpha;
int all_moves_lose=1;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;
int score;
int hf=0, ht=0;
long old_no=0, hi_no=0;

#ifdef LEARN
static int depth3sc=-32000;
#endif

ply=1;
maxply=0;
position[ply]=hash_board; 
l=nw;
root_alpha=alpha;
root_beta=beta;

#if 0
#ifdef LEARN
     t=pfoundpos(hash_board, &score, &hf, &ht);
       if (t)
	 {
	 /* fprintf(stdout, "Wow! found a position in the PERM hash table\n");
	 switch(t)
	   {
	   case EXACT: fprintf(stdout, "EXACT score move is %s score is %d\n",toalg(hf,ht),score); break;
	   } */
	n=score;
	mpf=hf;
	mpt=ht;
	oldalpha=alpha;
	alpha=n;
	if (DMAX>QUIET_PLY)
	    {
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	    if (n<beta)
		printf("Time = %.1f secs Best = %s Score = %d\n",time_used,toalg(mpf,mpt),n);
	    if (n>=beta)
		printf("Time = %.1f secs Best = %s Score >= %d\n",time_used,toalg(mpf,mpt),n);
	    }
	oldkf=killerfrom[ply];
	oldkt=killerto[ply];
	killerfrom[ply]=mpf;
	killerto[ply]=mpt;
	if (!ep&&mpf<MACHINE_CASTLES)           
	{
	(hist[mpf][mpt])+=histval[DMAX-ply];   
	if (hist[mpf][mpt]>maxhist) clear_hist_table();
	}
	pc(mpf,mpt);
	 rkiller(l);
	 if (DMAX>QUIET_PLY)
    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bBest move after search to depth (%d/%d): %s ", DMAX-1, maxply, toalg(killerfrom[ply], killerto[ply]));
return(alpha);

	 }
#endif
#endif
     
/*
     t=foundpos(hash_board, &score, &hf, &ht);
       if (t)
	 {
	 fprintf(stdout, "Wow! found a position in the hash table\n");   
	 switch(t)
	   {
	   case EXACT: fprintf(stdout, "EXACT score move is %s score is %d\n",toalg(hf,ht),score); break;
	   }
	n=score;
	mpf=hf;
	mpt=ht;
	oldalpha=alpha;
	alpha=n;
	if (DMAX>QUIET_PLY)
	    {
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	    if (n<beta)
		printf("Time = %.1f secs Best = %s Score = %d\n",time_used,toalg(mpf,mpt),n);
	    if (n>=beta)
		printf("Time = %.1f secs Best = %s Score >= %d\n",time_used,toalg(mpf,mpt),n);
	    }
	oldkf=killerfrom[ply];
	oldkt=killerto[ply];
	killerfrom[ply]=mpf;
	killerto[ply]=mpt;
	if (!ep&&mpf<MACHINE_CASTLES)           
	{
	(hist[mpf][mpt])+=histval[DMAX-ply];   
	if (hist[mpf][mpt]>maxhist) clear_hist_table();
	}
	pc(mpf,mpt);
	 rkiller(l);
	 if (DMAX>QUIET_PLY)
    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bBest move after search to depth (%d/%d): %s ", DMAX-1, maxply, toalg(killerfrom[ply], killerto[ply]));
return(alpha);

	 }
*/
	   
	   ic[ply]=0;
	   if (fastgenlbcheck(wkp))
	    {
	    ic[ply]=1;
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    }
	   

wibble:
for (p=(ply<<7);p<=l;p++)
    {
    p1=p;

    if (!fail_hi&&p!=(ply<<7))
	beta=alpha+1;
    if (DMAX>QUIET_PLY)
	{
	if (!fail_lo&&!fail_hi)
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b(%d/%d) %s [%d,%d]", p+1-((ply<<7)),l+1-((ply<<7)),toalg(plyf[p], plyt[p]), alpha, beta);
	if (fail_hi)
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b(%d/%d) %s! [%d,%d]", p+1-((ply<<7)),l+1-((ply<<7)),toalg(plyf[p], plyt[p]), alpha, beta);
	if (fail_lo)
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b(%d/%d) %s? [%d,%d]", p+1-((ply<<7)),l+1-((ply<<7)),toalg(plyf[p], plyt[p]), alpha, beta);
	fflush(stdout);
	}
    g_root=n=root[p];
    t=n;

	       if (plyf[p1]>MACHINE_CASTLES)
		   {
		   makecastle(plyf[p1]);
		   WMAKEMOVEC(p1);
		   create_hash_for_board();  /* update hash */
		   }
		else
		{
	       WMAKEMOVE(p1);
	       }
/*    if (ep) DMAX++; */

    old_no=no;
    if (occurred_before())
	{
	/* position has occurred before => score of 0 */
	/* fprintf(stdout, "\nposition has occurred before => score is 0\n"); */
	n=0;
	}
    else
	{
	n=b_search(beta,alpha,(n+v[ep]));
	}
/*    if (ep) DMAX--; */

    o[p1]=no-old_no;

    if (all_moves_lose&&ply<DMAX)
	if (!fastgenlbcheck(wkp))
	    all_moves_lose=0;

    if (STOP)
	{
	printf("#");
	n=alpha;
	}

    if (mpf>MACHINE_CASTLES) {unmakecastle(mpf); WUNMAKEMOVEC(p1); hash_board=old_hash_board;}
	    else
	       {
	       WUNMAKEMOVE(p1);
	       }

    /* only searched first move, but it's ok.. let's save some time.. */
#if 0
    if (p==(ply<<7)&&n>=root_alpha+25&&alpha==root_alpha&&beta==root_beta&&time_used>min_time&&n>=-25)
	{
#ifdef DEBUG
	fprintf(stdout, "TIMESAVER! n is %d root_alpha %d root_beta %d\n",n,root_alpha,root_beta);
#endif
	oldkf=killerfrom[ply];
	oldkt=killerto[ply];
	killerfrom[ply]=mpf;
	killerto[ply]=mpt;
	if (!ep&&mpf<MACHINE_CASTLES)           
	{
	(hist[mpf][mpt])+=histval[DMAX-ply];   
	if (hist[mpf][mpt]>maxhist) clear_hist_table();
	}
	pc(mpf,mpt);
	return(n);
	}
#endif

    if (n>alpha)
	{
	oldalpha=alpha;
	alpha=n;
	if (DMAX>QUIET_PLY)
	    {
	    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
	    if (n<beta)
		printf("Time = %.1f secs Best = %s Score = %d\n",time_used,toalg(mpf,mpt),n);
	    if (n>=beta)
		printf("Time = %.1f secs Best = %s Score >= %d\n",time_used,toalg(mpf,mpt),n);
	    }
	oldkf=killerfrom[ply];
	oldkt=killerto[ply];
	killerfrom[ply]=mpf;
	killerto[ply]=mpt;
	if (!ep&&mpf<MACHINE_CASTLES)           
	{
	(hist[mpf][mpt])+=histval[DMAX-ply];   
	if (hist[mpf][mpt]>maxhist) clear_hist_table();
	}
	pc(mpf,mpt);
	}
    else
	{
	if (!fail_hi&&p==(ply<<7)&&!STOP)
	    {
	    beta=n+1;

	switch (fail_lo)
	   {
	   case (0): alpha=n-28; /* look for positional gain.. */
		     fail_lo=1;
		     break;
	   case (1): alpha=n-175; /* look for material gain..*/
		     fail_lo=2;
		     break;
	   case (2): alpha=-32000; /* look for mate..*/
		     fail_lo=3;
		     break;
	   }


	    p--;
	    if (DMAX>QUIET_PLY)
		{
		printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b                \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
		printf("Time = %.1f secs Best = %s Score <= %d\n",time_used,toalg(mpf,mpt),n);
		}
	    continue;
	    }
	}


    if (STOP) break;
    
    if (!fail_lo&&n>=beta&&n<32000)
	{
	alpha=n-1;

	switch (fail_hi)
	   {
	   case (0): beta=n+28; /* look for positional gain.. */
		     fail_hi=1;
		     break;
	   case (1): beta=n+175; /* look for material gain..*/
		     fail_hi=2;
		     break;
	   case (2): beta=32000; /* look for mate..*/
		     fail_hi=3;
		     break;
	   }


	
	root_alpha=alpha;
	root_beta=beta;
	/*
	if (DMAX>QUIET_PLY)
	    printf("Researching this move with window (%d,%d)\n",alpha,beta); 
	*/
	pcf[1][2]=pct[1][2]=0;
	p--;
	continue;
	}
    n=t;
    fail_hi=fail_lo=0;
    }

#if STALEDETECT
if (all_moves_lose && !ic[ply])
    {
    /*
    if (beta<0)
	alpha=beta;
    else
    if (alpha<0)
	alpha=0;
    */ 
    alpha=0;
    }
#endif

for (p=(ply<<7);p<=l;p++)
    if (o[p]>hi_no)
	hi_no=o[p];

for (p=(ply<<7);p<=l;p++)
    if ((killerfrom[ply]==plyf[p])&&
	(killerto[ply]==plyt[p]))
	o[p]=hi_no+1;

rsort((ply<<7),l);

#if 0
#if DEBUG
fprintf(stdout,"\n");
for (p=(ply<<7);p<=l;p++)
    fprintf(stdout, "(%s %d) ",toalg(plyf[p],plyt[p]),o[p]);
fprintf(stdout,"\n");
#endif
#endif

/* ensure our best moves goes to top of list
for (p=(ply<<7);p<=l;p++)
    if ((killerfrom[ply]==plyf[p])&&
	(killerto[ply]==plyt[p]))
	    o[p]+=1000; */

#ifdef  LEARN
if (DMAX==4)
    depth3sc=alpha;
if (!STOP)
   {
   /*if (DMAX>3 && alpha<depth3sc-15) */
   if (DMAX>3)
      if (1)
	  {
	  /* fprintf(stdout,"\nStoring move %s with score %d in permenant hash\n",toalg(killerfrom[ply],killerto[ply]),alpha); */
	  pstorepos(hash_board, killerfrom[ply],killerto[ply], oldalpha, beta, alpha);
	  }
   }
#endif

rkiller(l);
if (DMAX>QUIET_PLY)
    printf("\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bBest move after search to depth (%d/%d): %s ", DMAX-1, maxply, toalg(killerfrom[ply], killerto[ply]));
return(alpha);
}

#include "quieschz.c"

static int wettc(alpha,beta,n)
int alpha,beta,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
int ext=0;
int oldalpha=alpha;
int score;
int hf=0, ht=0;
int bf=0,bt;
int all_moves_lose=1;
int hack_from=0, hack_to=0;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;

/* printf("called b_search\n"); */
     wch=bch=0;
     ply++;
     no++;
     pcf[ply][ply]=0;
     if (ic[ply-1])
	{
	if (fastgenlbcheck(wkp))
	    {
	    alpha=-20000+(7*ply);
	    ply--;
	    return (alpha);
	    }
	}
     ic[ply]=0;
     position[ply]=hash_board;
     
     for (i=ply-4; i>0; i-=2)
     if (hash_board==position[i])
	 {
	 DMAX-=ext;
	 ply--;
	 /*printf("alpha is %d beta is %d returning 0\n",alpha,beta);*/
	 return(0);
	 }
     if (!null[ply-1]&&fastgenlwcheck(bkp))
	    {
	    ext++;
	    ic[ply]=1;
	    DMAX++;
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    /* printf("(DMAX=%d)",DMAX); */
	    }
     t=bfoundpos(hash_board, &score, &hf, &ht);
     if (t)     
	 {
	 if (t==EXACT)
	     {
	     pcf[ply][ply]=0;
	     DMAX-=ext;
	     ply--;
	     return(score);
	     }
	 if (t==UPPER_BOUND)
	     {
	     if (score <= beta)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     }
	 if (t==LOWER_BOUND)
	     {
	     if (score >= alpha)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     }
	 }
DMAX-=ext;
ply--;
return(-32000);
}


static int bettc(alpha,beta,n)
int alpha,beta,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
int oldalpha=alpha;
int ext=0, score;
int hf=0, ht=0;
int bf=0, bt;
int all_moves_lose=1;
int hack_from=0, hack_to=0;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;

/* printf("called wsearch\n"); */
     wch=bch=0;
     ply++;
     no++;
     pcf[ply][ply]=0;
#if 0
     if (ic[ply-1])
	{
	if (fastgenlwcheck(bkp))
	    {
	    alpha=10000-(7*ply);
	    ply--;
	    return (alpha);
	    }
	}
#endif
     ic[ply]=0;
     position[ply]=hash_board;
     for (i=ply-4; i>0; i-=2)
     if (hash_board==position[i])
	 {
	 DMAX-=ext;
	 ply--;
	 /*printf("alpha is %d beta is %d returning 0\n",alpha,beta);   */
	 return(0);
	 }
     if (!null[ply-1]&&fastgenlbcheck(wkp))
	    {
	    ext++;
	    ic[ply]=1;
	    DMAX++;
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    /* printf("(DMAX=%d)",DMAX); */
	    }
     t=foundpos(hash_board, &score, &hf, &ht);
     if (t)     
	 {
	 if (t==EXACT)
	     {
	     /* printf("*****exact score******\n"); */
	     pcf[ply][ply]=0;
	     DMAX-=ext;
	     ply--;
	     return(score);
	     }  
	 if (t==LOWER_BOUND)
	     {
	     /* printf("found in hash table\nscore was %d\n",score); */
	     /* printf("current depth %d\nDMAX %d\n",ply,DMAX);
	     printboard(); */
	     if (score >= beta)
		 {
		 /* printf("********beta cut******\n");  */
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     }
	 if (t==UPPER_BOUND)
	     {
	     if (score <= alpha)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     }
	 }

DMAX-=ext;
ply--;
return(32000);
}


static int b_search(alpha,beta,n)
int alpha,beta,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
int ext=0;
int oldalpha=alpha;
int score;
int hf=0, ht;
int bf=0,bt;
int all_moves_lose=1;
int hack_from=0, hack_to;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;

fp=0;
ep=0;

if (ply>60)
    return(beta);

/* printf("called b_search\n"); */
     wch=bch=0;
     ply++;
     no++;
     pcf[ply][ply]=0;

     if (ic[ply-1])
	{
	if (fastgenlbcheck(wkp))
	    {
	    alpha=-20000+(7*ply);
	    ply--;
	    return (alpha);
	    }
	}
     ic[ply]=0;
     position[ply]=hash_board;
     for (i=ply-4; i>0; i-=2)
     if (hash_board==position[i])
	 {
	 bclearhashentry(hash_board);
	 clearhashentry(position[ply-1]);
	 ply--;
	 /*printf("alpha is %d beta is %d returning 0\n",alpha,beta);*/
	 return(0);
	 }
     if (!null[ply-1]&&fastgenlwcheck(bkp))
	    {
	    ic[ply]=1;
	    ext++;
	    DMAX++;
	    if (n>500) /* lost, so don't bother extending.. */
		{
		ext--;
		DMAX--;
		}
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    /* printf("(DMAX=%d)",DMAX); */
	    }


	     /* razoring? */
#ifdef RAZOR
     if (ply==DMAX&&n+200<=beta)
	 {
	 ply--;
	 return(n);
	 }

     if (ply==DMAX-1&&!ic[ply]&&!null[ply-1]&&n+200<=beta)
	 {
	 ply--;
	 return(n);
	 }
     if (ply==DMAX-2&&!ic[ply]&&!null[ply-1]&&n+500<=beta)
	 {
	 ply--;
	 return(n);
	 }
     if (ply==DMAX-3&&!ic[ply]&&!null[ply-1]&&n+900<=beta)
	 {
	 ply--;
	 return(n);
	 }

#if 0
     if (ply==DMAX-1&&!ic[ply]&&!null[ply-1]&&n-50>=alpha)
	 {
	 n=b_search(alpha,beta,n);
	 ply--;
	 return(n);
	 }


     if ((ply==DMAX-1||ply==DMAX-2)&&!ic[ply]&&!null[ply-1]&&n<=beta+200)
	 {
	 t=eval(pawn_hash_board);
	 if (n+t<=beta)
	     {
	     ply--;
	     return(n+t);
	     }
	 }
#endif

#endif
     t=bfoundpos(hash_board, &score, &hf, &ht);
     if (t)     
	 {
	 if (t==UPPER_BOUND)
	     {
	     if (score <= beta)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     if (score < alpha)             
		 {
		 alpha=score;
		 }
	     }
	 if (t==LOWER_BOUND)
	     {
	     if (score >= alpha)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     if (score > beta)
		 {
		 beta=score;
		 }
	     }
	 if (t==EXACT)
	     {
	     pcf[ply][ply]=0;
	     DMAX-=ext;
	     ply--;
	     return(score);
	     }

	 }


if (ply<DMAX-4)
    {
    genlegalblack();
    if (wch) {alpha=-20000+(7*ply); DMAX-=ext; ply--; return(alpha);}
    else
	{
	l=nb;
	t=n;
	for (p=(ply<<7);p<=l;p++)
	  {
	  p1=p;    
	  BMAKEMOVE(p1);
	  n-=v[ep];
	  n=bettc(beta,alpha,n);
	  BUNMAKEMOVE(p1);
	  if (n<=beta) {/* printf("[ETTC (B)!]"); bstorepos(hash_board, mpf,mpt, oldalpha, beta, n); */ ply--; DMAX-=ext; return(n);}
	  n=t;
	  }
	}
    }



     if (ply==DMAX)
	{
	if (n+200<=beta) {ply--; return(n);}
	if (n-200>=alpha)
	;
	else
	{
	int s;
#if 0
	if (foundpawneval(pawn_hash_board, &score))
	    {
	    s=score;
	    }
	else
	    {
	    s=dynpawnscore();
	    storepawneval(pawn_hash_board, s);
	    }
	if (n+s+60<=beta) {ply--; return(n+s);}
	king_hash_board=pawn_hash_board;
	king_hash_board^=hash_code[WK][wkp];
	king_hash_board^=hash_code[BK][bkp];
	if (foundkingeval(king_hash_board, &score))
	    {
	    s+=score;
	    }
	else
	    {
	    score=dynkingscore();
	    s+=score;
	    storekingeval(king_hash_board, score);
	    }
#endif
	s=eval(hash_board,pawn_hash_board);
	if (n+s<=beta) {ply--; return(s+n);}
	if (alpha>n+s) alpha=n+s; 
	}
	}
     
/* null moves may be used in endgame if side to move has one piece */
     if (end_game)
	 {
	 int *p;
	 int do_null=0;
	 int pieceval=0;

	 for (p=&bsq[0];(p!=lbp);p++) 
	     if ((b[*p]&START_BLACK_PIECES)&&(b[*p]!=BP)&&(b[*p]!=BK))
		 {
		 do_null=1;
		 pieceval+=v[b[*p]];
		 }

	 /* if we've got a rook or less, piecewize, only do */
	 /* nulls near the leaves */
	 if (do_null && pieceval<=v[BR] && ply<DMAX-9)
	     do_null=0;

	 if (do_null&&(!null[ply-1])&&(!ic[ply])&&(ply<=DMAX-2))
	    {

	int R=2;

	if (ply<DMAX-5)
	    R=3;

	DMAX-=R;
	null[ply]=1;
	if (ply>DMAX-1)
	t=wquiesce(beta, beta+1, n);
	else
	t=wsearch(beta, beta+1, n);
	null[ply]=0;
	DMAX+=R;
	 
	    if (t<=beta) {ply--; return(t);}
	}

	 }
else
     if ((!null[ply-1])&&(!ic[ply])&&(ply<=DMAX-2))
	{
	int R=2;

	if (ply<DMAX-5)
	    R=3;

	DMAX-=R;
	null[ply]=1;
	if (ply>DMAX-1)
	t=wquiesce(beta, beta+1, n);
	else
	t=wsearch(beta, beta+1, n);
	null[ply]=0;
	DMAX+=R;
	 
	    if (t<=beta) {ply--; return(t);} 
	}

     /* try move from hash table next */
				      
/* printf("\n->"); */

     
#ifdef IID
     if (!hf && ply < DMAX-2 &&
	 alpha == root_beta &&
	 beta == root_alpha)
	 {
	 DMAX--;
	 t=b_search(alpha, beta, n);
	 if (t>=alpha)
	     t=b_search(32000, alpha-1, n);
	 DMAX++;

	 DMAX-=10;
	 bfoundpos(hash_board, &score, &hf, &ht);
	 DMAX+=10;
	 printf("(B) hash_move is now %s\n", toalg(hf,ht));
	 }
#endif

     if (hf)
     {
     if (check_if_legal_for_black(hf,ht))
	 {
	 if (wch) {alpha=-20000+(7*ply); DMAX-=ext; ply--; return(alpha);}
	 /* printf("[H %s]\n",toalg(hf,ht)); */
	 p=(ply<<7);
	 plyf[p]=hf;
	 plyt[p]=ht;
	 t=n;
	 BMAKEMOVE(p);
	 n-=v[ep];
	 if (ply<DMAX)
	     {
	     n=wsearch(beta,alpha,n);
	     if (all_moves_lose)
	       if (!fastgenlwcheck(bkp))
		 all_moves_lose=0;
	     }
	 else if (n-200<alpha) 
	     {
	     n=wquiesce(beta,alpha,n);
	     }
	 BUNMAKEMOVE(p);
	 if (n<alpha) { alpha=n;
			if (!ep)
			{
			hist[mpf][mpt]+=histval[DMAX-ply];
			if (hist[mpf][mpt]>maxhist) clear_hist_table();
			killerfrom[ply]=mpf;
			killerto[ply]=mpt;
			}
			if (n<=beta) {/* printf("[BH]"); */bstorepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
			pc(mpf,mpt);
			bf=mpf;
			bt=mpt;
			}
	 n=t;
	 }
     }

/* now look at captures */

	  genlegalblackcap();
	  if (wch) {alpha=-20000+(7*ply); DMAX-=ext; ply--; return(alpha);}
	  else
	  {
	  l=nb;
	  t=n;

#if 0
	  if (ply==DMAX)
	      {
	      for (p=(ply<<7);p<=l;p++)
		  {
		  if (hf && plyf[p1]==hf && plyt[p1]==ht)
		      continue;
		  BMAKEMOVE(p);
		  printboard();
		  printf("wsee on %d gave %d\n",mpt,wsee(-1,1,0,mpt));
		  BUNMAKEMOVE(p);
		  }
	      }

#endif

	  for (p=(ply<<7);p<=l;p++)
	  {
		p1=gnextbest(l);    
		if (hf && plyf[p1]==hf && plyt[p1]==ht)
		    continue;
	  
	  
	  BMAKEMOVE(p1);
	  /* printf("[C %s]\n",toalg(mpf,mpt)); */
	  n-=v[ep];
	  if (ply<DMAX)
	      {
		n=wsearch(beta,alpha,n);
		if (all_moves_lose)
		  if (!fastgenlwcheck(bkp))
		    all_moves_lose=0;
	      }
	  else 
	       {
	       if (n-200<alpha) 
	       {
#if 0
	       int zz=wsee(-10000,10000,-v[ep],mpt);
	       if (v[ep]<v[fp]&&mpt==53)
		   {
		   BUNMAKEMOVE(p1);
		   printf("VVV cap on %d\n",mpt);
		   printf("VVV alpha %d beta %d n %d wsee %d\n",alpha, beta,n,zz);
		   printboard();
		   BMAKEMOVE(p1);
		   }
#endif

#if 0
	       if (v[ep]<v[fp] && (wsee(-1,1,n-t,mpt)>0 && wquiesce(beta,alpha,n)<alpha))
		       {
		       BUNMAKEMOVE(p1);
		       printf("(B) VVV poss error on cap on sqare %d\n",mpt);
		       printboard();
		       BMAKEMOVE(p1);
		       }
#endif

		
	       if (absv[ep]>=absv[fp]||fp==BP&&mpt<29||wsee(-1,1,-absv[ep],mpt)<=0)
		   n=wquiesce(beta,alpha,n);
	       else {BUNMAKEMOVE(p1); n=t; continue;}
	       }
	       else {BUNMAKEMOVE(p1); n=t; break;}
	       }
	       

	   BUNMAKEMOVE(p1);
	       if (n<alpha) 
		   {
		   alpha=n;
		   if (n<=beta) {/* printf("[BC]"); */bstorepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
		   pc(mpf,mpt);
		   bf=mpf;
		   bt=mpt;
		   }
	   n=t;
	  }

	  }


/* try killer move next */
     
     if (ply<DMAX&&killerfrom[ply]&&!b[killerto[ply]]&&(killerfrom[ply]!=hf&&killerto[ply]!=ht))
     {
     if (check_if_legal_for_black_non_cap(killerfrom[ply],killerto[ply]))
	 {
	 /* if (wch) {alpha=-20000+(7*ply); DMAX-=ext; ply--; return(alpha);}*/
	 p=(ply<<7);
	 plyf[p]=killerfrom[ply];
	 plyt[p]=killerto[ply];

	 FBMAKEMOVE(p);
	 
	 
	 /* printf("[K %s]\n",toalg(mpf,mpt)); */
	 n=wsearch(beta,alpha,n);
	 if (all_moves_lose)
	     if (!fastgenlwcheck(bkp))
	     /* if (n!=10000-(7*(ply+1))) */
		 all_moves_lose=0;
	 FBUNMAKEMOVE(p);
	 if (n<alpha) { alpha=n;
			hist[mpf][mpt]+=histval[DMAX-ply];
			if (hist[mpf][mpt]>maxhist) clear_hist_table();
			if (n<=beta) {/* printf("[BK]"); */bstorepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
			pc(mpf,mpt);
			bf=mpf;
			bt=mpt;
			}
	 hack_from=mpf;
	 hack_to=mpt;
	 n=t;
	 }
     }

     
     /* only now look at other moves */
     
	  if (ply<DMAX) 
	  {
	  int futile=0;   
	  genlegalblacknoncap();          
	  l=nb;   
	  if (ply==DMAX-1&&n>=alpha+200)                
	      futile=1;         
	  if (ply==DMAX-2&&n>=alpha+200)         
	      futile=1;          
	  if (ply==DMAX-3&&n>=alpha+500)                
	      futile=1;          
	  if (ply==DMAX-4&&n>=alpha+900)                
	      futile=1;
	  if (futile) all_moves_lose=0;
	  for (p=(ply<<7);p<=l;p++)       
	  {       
	  p1=gnextbest(l);              
	  if (futile&&unlikelycheck(b[plyf[p1]],plyt[p1],wkp))               
	      continue;   
	  if (hf && plyf[p1]==hf && plyt[p1]==ht)
		    continue;
	  if (plyf[p1]==hack_from && plyt[p1]==hack_to)
		    continue;
      /* if (ply>=DMAX-5&&!ic[ply]&&hist[plyf[p1]][plyt[p1]]<128&&p>((ply<<7)+4)&&!(alpha == root_beta && beta == root_alpha)) {continue;} */
	  /*
	  if (plyf[p1]==killerfrom[ply] && plyt[p1]==killerto[ply])
		    continue;
	  if (plyf[p1]==hack_from && plyt[p1]==hack_to)
	      {
	      printf("(B) Waste: %d ply\n", DMAX-ply);
	      }
	  */
	  FBMAKEMOVE(p1);
	  if (ply<=DMAX-3 && !ic[ply]&&hist[plyf[p1]][plyt[p1]]<9500&&p>((ply<<7)+1)&&!(alpha == root_beta && beta == root_alpha)) 
	  {
      int R=1;

	  if (hist[plyf[p1]][plyt[p1]]<1600) R++;

	  DMAX-=R;
	  t=wsearch(beta,alpha,n);
	  DMAX+=R;
	  if (t<alpha) t=wsearch(beta,alpha,n);
	  }
	  else
	  t=wsearch(beta,alpha,n);



	  /* printf("[Normal %s]\n",toalg(mpf,mpt)); */
		  
	  if (all_moves_lose)
	     if (!fastgenlwcheck(bkp))
	     /* if (n!=10000-(7*(ply+1))) */
		 all_moves_lose=0;

	   FBUNMAKEMOVE(p1);
	       if (t<alpha) 
		   {
		   alpha=t;
		   hist[mpf][mpt]+=histval[DMAX-ply]; 
		   if (hist[mpf][mpt]>maxhist) clear_hist_table();
		   killerfrom[ply]=mpf;
		   killerto[ply]=mpt;
		   if (t<=beta) {/* printf("[BN]"); */ bstorepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
		   pc(mpf,mpt);
		   bf=mpf;
		   bt=mpt;
		   }
	   if (STOP) break;
	  }

	  }


     if (!ic[ply]&&end_game)
	 {
	 t=deaddraw();
#if DEBUG
         if (t) printboard();
         #endif
	 if (t==EXACT)
	     {
	     ply--;
	     return(0);
	     }
         if (t==UPPER_BOUND) /* at most for CPU */
	     {
             if (alpha>0)
                alpha=0;
             }
         if (t==LOWER_BOUND) /* at least for CPU */
	     {
             if (alpha<0)
                alpha=0;
	     }
	 }



#if STALEDETECT
if (all_moves_lose && ply<DMAX && !ic[ply])
    {
    /*
    if (beta>0)
	alpha=beta;
    else
    if (alpha>0)
	alpha=0;
    */
    alpha=0;
    DMAX-=ext;
    ply--;
    return(alpha);
    }
#endif

/* if (ic[ply]&&l<(ply<<7))
    alpha=10000-(7*(ply+1)); */

/* if we're in check, and lost return mate score..
if (ic[ply]&&alpha>8800)
    alpha=10000-(7*(ply+1));
*/

     if (alpha!=oldalpha)
	 bstorepos(hash_board, bf,bt, oldalpha, beta, alpha); 
     else
	 bstorepos(hash_board,0,0,oldalpha,beta,alpha);
     ply--;
     DMAX-=ext;
     return(alpha);
}


static int wsearch(alpha,beta,n)
int alpha,beta,n;
{
register int p;
int p1,l,fp,ep,mpf,mpt,t;
int oldalpha=alpha;
int ext=0, score;
int hf=0, ht;
int bf=0, bt;
int all_moves_lose=1;
int hack_from=0, hack_to;
BITBOARD old_hash_board=hash_board, old_pawn_hash_board=pawn_hash_board;

fp=0;
ep=0;

if (ply>60)
    return(beta);

/* printf("called wsearch\n"); */
     wch=bch=0;
     ply++;
     no++;
     pcf[ply][ply]=0;

     if (ic[ply-1])
	{
	if (fastgenlwcheck(bkp))
	    {
	    alpha=10000-(7*ply);
	    ply--;
	    return (alpha);
	    }
	}
     ic[ply]=0;
     position[ply]=hash_board;
     for (i=ply-4; i>0; i-=2)
     if (hash_board==position[i])
	 {
	 clearhashentry(hash_board);
	 bclearhashentry(position[ply-1]);
	 ply--;
	 /*printf("alpha is %d beta is %d returning 0\n",alpha,beta);   */
	 return(0);
	 }
     if (!null[ply-1]&&fastgenlbcheck(wkp))
	    {
	    ext++;
	    ic[ply]=1;
	    DMAX++;
	    if (n<-500) /* lost, so don't bother extending.. */
		{
		ext--;
		DMAX--;
		}
	    all_moves_lose=0; /* saves work, as we only use this to look for stalemates */
	    /* printf("(DMAX=%d)",DMAX); */
	    }



	 
	 
	 /* razoring? */
#ifdef RAZOR
     if (ply==DMAX&&n-200>=beta)
	 {
	 ply--;
	 return(n);
	 }

     if (ply==DMAX-1&&!ic[ply]&&!null[ply-1]&&n-200>=beta)
	 {
	 ply--;
	 return(n);
	 }
     if (ply==DMAX-2&&!ic[ply]&&!null[ply-1]&&n-500>=beta)
	 {
	 ply--;
	 return(n);
	 }
     if (ply==DMAX-3&&!ic[ply]&&!null[ply-1]&&n-900>=beta)
	 {
	 ply--;
	 return(n);
	 }

#if 0
     if (ply==DMAX-1&&!ic[ply]&&!null[ply-1]&&n+50<=alpha)
	 {
	 n=wsearch(alpha,beta,n);
	 ply--;
	 return(n);
	 }

     if ((ply==DMAX-1||ply==DMAX-2)&&!ic[ply]&&!null[ply-1]&&n>=beta-150)
	 {
	 t=eval(pawn_hash_board);
	 if (n+t>=beta)
	     {
	     ply--;
	     return(n+t);
	     }
	 }
#endif
#endif
#ifdef LEARN
     t=pfoundpos(hash_board, &score, &hf, &ht);
       if (t)
	 {
	 /* fprintf(stdout, "Wow! found a position in the PERM hash table\n"); */
	 
	 switch(t)
	   {
	   case EXACT:break;
	   case LOWER_BOUND: fprintf(stdout, "LOWER BOUND on score\n"); break;
	   case UPPER_BOUND: fprintf(stdout, "UPPER BOUND on score\n"); break;
	   }
	 /*
	 DMAX+=10;
	 if (!check_if_legal_for_white(hf,ht))
	     {
	     fprintf(stdout, "arse DMAX=%d ply=%d\n",DMAX,ply);
	     fprintf(stdout, "move %s is not legal\n",toalg(hf,ht));
	     printboard();
	     }
	 DMAX-=10;
	 */
	 }
     else
#endif
     t=foundpos(hash_board, &score, &hf, &ht);
     if (t)     
	 {
	 if (t==LOWER_BOUND)
	     {
	     /* printf("found in hash table\nscore was %d\n",score); */
	     /* printf("current depth %d\nDMAX %d\n",ply,DMAX);
	     printboard(); */
	     if (score >= beta)
		 {
		 /* printf("********beta cut******\n");  */
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     if (score > alpha)             
		 {
		 /* printf("narrowed window from [%d,%d] to [%d,%d]\n",alpha,beta,score,beta); */
		 alpha=score;
		 }
	     }
	 if (t==UPPER_BOUND)
	     {
	     if (score <= alpha)
		 {
		 pcf[ply][ply]=0;
		 DMAX-=ext;
		 ply--;
		 return(score);
		 }
	     if (score < beta)
		 {
		 /* printf("narrowed window from [%d,%d] to [%d,%d]\n",alpha,beta,alpha,score); */
		 beta=score;
		 }
	     }
         if (t==EXACT)
	     {
	     /* printf("*****exact score******\n"); */
	     pcf[ply][ply]=0;
	     DMAX-=ext;
	     ply--;
	     return(score);
	     }  
	 }
     
     
if (ply<DMAX-4)     
    {
    genlegalwhite();
    if (bch) {alpha=10000-(7*ply); DMAX-=ext; ply--; return(alpha);}
    else
	{
	l=nw;
	t=n;

	for (p=(ply<<7);p<=l;p++)
	    {
	       p1=p;
	       WMAKEMOVE(p1);
	       n+=v[ep];
	       n=wettc(beta,alpha,n);
	       WUNMAKEMOVE(p1);
	       if (n>=beta) {/* printf("[ETTC!]"); storepos(hash_board, mpf, mpt, oldalpha, beta, n); */ ply--; DMAX-=ext; return(n);}
	       n=t;
	    }
	}
    }

     if (ply==DMAX)
		{
		if (n-200>=beta) {ply--; return(n);}
		if (n+200<=alpha)
		;
		else
		{
		int s;
#if 0
		if (foundpawneval(pawn_hash_board, &score))
			{
			s=score;
			}
		else
			{
			s=dynpawnscore();
			storepawneval(pawn_hash_board, s);
			}
		if (n+s-60>=beta) {ply--; return(n+s);}
		king_hash_board=pawn_hash_board;
		king_hash_board^=hash_code[WK][wkp];
		king_hash_board^=hash_code[BK][bkp];
		if (foundkingeval(king_hash_board, &score))
			{
			s+=score;
			}
		else
			{
			score=dynkingscore();
			s+=score;
			storekingeval(king_hash_board, score);
			}
#endif
		s=eval(hash_board,pawn_hash_board);
		if (n+s>=beta) {ply--; return(n+s);}
		if (alpha<n+s) alpha=n+s;
		}
		}
/* null moves may be used in endgame if side to move has one piece */
     if (end_game)
	 {
	 int *p;
	 int do_null=0;
	 int pieceval=0;

	 for (p=&wsq[0];(p!=lwp);p++) 
	     if ((b[*p]&START_WHITE_PIECES)&&(b[*p]!=WP)&&(b[*p]!=WK))
		 {
		 do_null=1;
		 pieceval+=v[b[*p]];
		 }

	 /* if we've got a rook or less, piecewize, only do */
	 /* nulls near the leaves */
	 if (do_null && pieceval<=v[WR] && ply<DMAX-9)
	     do_null=0;

     if (do_null&&(!null[ply-1])&&(!ic[ply])&&(ply<=DMAX-2))
	{
	int R=2;

	if (ply<DMAX-5)
	    R=3;

	DMAX-=R;
	null[ply]=1;
	if (ply>DMAX-1)
	t=bquiesce(beta, beta-1, n);
	else
	t=b_search(beta, beta-1, n);
	null[ply]=0;
	DMAX+=R;

	    if (t>=beta) {ply--; return(t);}
	}
	 
     }    
else
     if ((!null[ply-1])&&(!ic[ply])&&(ply<=DMAX-2))
	{
	int R=2;

	if (ply<DMAX-5)
	    R=3;

	DMAX-=R;
	null[ply]=1;
	if (ply>DMAX-1)
	t=bquiesce(beta, beta-1, n);
	else
	t=b_search(beta, beta-1, n);
	null[ply]=0;
	DMAX+=R;

	    if (t>=beta) {ply--; return(t);}

#ifdef THREATEXT
	if ((ply==DMAX-2||ply==DMAX-3)&&(n>=beta)&&(t<n-150)&&(DMAX<OMAX))
	    {
	    ext++;
	    DMAX++;
	    }
#endif

	}


#ifdef IID
     if (!hf && ply < DMAX-2 &&
	 alpha == root_alpha &&
	 beta == root_beta)
	 {
	 DMAX--;
	 t=wsearch(alpha, beta, n);
	 if (t<=alpha)
	     t=wsearch(-32000, alpha+1, n);
	 DMAX++;
	 DMAX-=10;
	 foundpos(hash_board, &score, &hf, &ht);
	 DMAX+=10;
	 printf("(W) hash_move is now %s\n", toalg(hf,ht));
	 }
#endif

      
     /* try move from hash table next */
     
     if (hf)
     {
     if (check_if_legal_for_white(hf,ht))
	 {
	 if (bch) {alpha=10000-(7*ply); DMAX-=ext; ply--; return(alpha);}
	 p=(ply<<7);
	 plyf[p]=hf;
	 plyt[p]=ht;
	 t=n;
	 WMAKEMOVE(p);
	 n+=v[ep];
	 if (ply<DMAX)
	     {
	     n=b_search(beta,alpha,n);
	     if (all_moves_lose)
	       if (!fastgenlbcheck(wkp))
		 all_moves_lose=0;

	     }
	 else if (n+200>alpha)
	 {
	 n=bquiesce(beta,alpha,n);
	 }

	 WUNMAKEMOVE(p);
	 if (n>alpha) { alpha=n;
			if (!ep)
			{
			killerfrom[ply]=mpf;
			killerto[ply]=mpt;
			hist[mpf][mpt]+=histval[DMAX-ply]; 
			if (hist[mpf][mpt]>maxhist) clear_hist_table();
			}
			if (n>=beta) {/* printf("[WH]"); */storepos(hash_board, mpf, mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
			pc(mpf,mpt);
			bf=mpf;
			bt=mpt;
			}
	 n=t;
	 }
     }

/* hash move done, now captures.. */

	  genlegalwhitecap();
	  if (bch) { alpha=10000-(7*ply); DMAX-=ext; ply--; return(alpha);}
	  else
	  {
	  l=nw;                                      
	  t=n;
#if 0
	  if (ply==DMAX)
	      {
	      for (p=(ply<<7);p<=l;p++)
		  {
		  if (hf && plyf[p1]==hf && plyt[p1]==ht)
		      continue;
		  WMAKEMOVE(p);
		  printboard();
		  printf("bsee on %d gave %d\n",mpt,bsee(10,-10,0,mpt));
		  WUNMAKEMOVE(p);
		  }
	      }
#endif

	  n=t;

	  for (p=(ply<<7);p<=l;p++)
	  {
	       p1=gnextbest(l);
	       if (hf && plyf[p1]==hf && plyt[p1]==ht)
		    continue;
	       WMAKEMOVE(p1);
	       n+=v[ep];
	       if (ply<DMAX)
		   {
		   n=b_search(beta,alpha,n);
		   if (all_moves_lose)
		     if (!fastgenlbcheck(wkp))
		       all_moves_lose=0;
		   }
	       else
		 {
		   if (n+200>alpha)
		   {
		   #if 0
		   if (v[ep]<v[fp] && (bsee(1,-1,n-t,mpt)<0 && bquiesce(beta,alpha,n)>alpha))
		       {
		       WUNMAKEMOVE(p1);
		       printf("VVV poss error on cap on sqare %d\n",mpt);
		       printboard();
		       WMAKEMOVE(p1);
		       }
		   #endif

		   if (absv[ep]>=absv[fp]||fp==WP&&mpt>90||bsee(1,-1,absv[ep],mpt)>=0)
		       n=bquiesce(beta,alpha,n);
		   else {WUNMAKEMOVE(p1); n=t; continue;}
		   }
		   else {WUNMAKEMOVE(p1); n=t; break;}
		 }


	       WUNMAKEMOVE(p1);
	       if (n>alpha) {alpha=n;
				if (n>=beta) {/* printf("[WC]"); */storepos(hash_board, mpf, mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}
	       n=t;
	  }
     }

/* try killer move next */
     
     if (ply<DMAX&&killerfrom[ply]&&!b[killerto[ply]]&&(killerfrom[ply]!=hf&&killerto[ply]!=ht))
     {
     if (check_if_legal_for_white_non_cap(killerfrom[ply],killerto[ply]))
	 {
	 /* if (bch) {alpha=10000-(7*ply); DMAX-=ext; ply--; return(alpha);} */
	 p=(ply<<7);
	 plyf[p]=killerfrom[ply];
	 plyt[p]=killerto[ply];
	 t=n;
	 FWMAKEMOVE(p);

	 n=b_search(beta,alpha,n);
	 if (all_moves_lose)
	     if (!fastgenlbcheck(wkp))
	     /* if (n!=-20000+(7*(ply+1))) */
		 all_moves_lose=0;

	 FWUNMAKEMOVE(p);
	 if (n>alpha) { alpha=n;
			hist[mpf][mpt]+=histval[DMAX-ply]; 
			if (hist[mpf][mpt]>maxhist) clear_hist_table();
			if (n>=beta) {/* printf("[WK]"); */ storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
			pc(mpf,mpt);
			bf=mpf;
			bt=mpt;
			}
	 hack_from=mpf;
	 hack_to=mpt;
	 n=t;
	 }
     }

/* castling move? */
     if (ply<DMAX&&CASTLE)
	{
	if ((colour==WHITE)&&(cancastle(MACHINE_CASTLE_W_K)))
		{
		wsq[30]=MACHINE_CASTLE_W_K;
		p1=ply<<7;
		plyt[p1]=plyf[p1]=MACHINE_CASTLE_W_K;
		makecastle(plyf[p1]);
		WMAKEMOVEC(p1);
		create_hash_for_board(); /* update hash */
		t=b_search(beta,alpha,n);
		WUNMAKEMOVEC(p1);
		unmakecastle(plyf[p1]);
		hash_board=old_hash_board; /* restore hash */
		if (t>alpha) {  alpha=t;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				hist[mpf][mpt]+=histval[DMAX-ply]; 
				if (hist[mpf][mpt]>maxhist) clear_hist_table();
				if (t>=beta) {/* printf("[WN]"); */storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}

		}
	if ((colour==WHITE)&&(cancastle(MACHINE_CASTLE_W_Q)))
		{
		wsq[30]=MACHINE_CASTLE_W_Q;
		p1=ply<<7;
		plyt[p1]=plyf[p1]=MACHINE_CASTLE_W_Q;
		makecastle(plyf[p1]);
		WMAKEMOVEC(p1);
		create_hash_for_board(); /* update hash */
		t=b_search(beta,alpha,n);
		WUNMAKEMOVEC(p1);
		unmakecastle(plyf[p1]);
		hash_board=old_hash_board; /* restore hash */
		if (t>alpha) {  alpha=t;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				hist[mpf][mpt]+=histval[DMAX-ply]; 
				if (hist[mpf][mpt]>maxhist) clear_hist_table();
				if (t>=beta) {/* printf("[WN]"); */storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}

		}
	if ((colour==BLACK)&&(cancastle(MACHINE_CASTLE_B_K)))
		{
		wsq[30]=MACHINE_CASTLE_B_K;
		p1=ply<<7;
		plyt[p1]=plyf[p1]=MACHINE_CASTLE_B_K;
		makecastle(plyf[p1]);
		WMAKEMOVEC(p1);
		create_hash_for_board(); /* update hash */
		t=b_search(beta,alpha,n);
		WUNMAKEMOVEC(p1);
		unmakecastle(plyf[p1]);
		hash_board=old_hash_board; /* restore hash */
		if (t>alpha) {  alpha=t;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				hist[mpf][mpt]+=histval[DMAX-ply]; 
				if (hist[mpf][mpt]>maxhist) clear_hist_table();
				if (t>=beta) {/* printf("[WN]"); */storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}

		}
	if ((colour==BLACK)&&(cancastle(MACHINE_CASTLE_B_Q)))
		{
		wsq[30]=MACHINE_CASTLE_B_Q;
		p1=ply<<7;
		plyt[p1]=plyf[p1]=MACHINE_CASTLE_B_Q;
		makecastle(plyf[p1]);
		WMAKEMOVEC(p1);
		create_hash_for_board(); /* update hash */
		t=b_search(beta,alpha,n);
		WUNMAKEMOVEC(p1);
		unmakecastle(plyf[p1]);
		hash_board=old_hash_board; /* restore hash */
		if (t>alpha) {  alpha=t;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				hist[mpf][mpt]+=histval[DMAX-ply]; 
				if (hist[mpf][mpt]>maxhist) clear_hist_table();
				if (t>=beta) {/* printf("[WN]"); */storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}

		}

	}

/* all other moves - non captures, ordered by history heuristic */

	  if (ply<DMAX)
	  {
	  int futile=0;   
	  genlegalwhitenoncap();          
	  l=nw;   
	  if (ply==DMAX-1&&n<=alpha-200)                
	      futile=1;         
	  if (ply==DMAX-2&&n<=alpha-200)         
	      futile=1;          
	  if (ply==DMAX-3&&n<=alpha-500)                
	      futile=1;           
	  if (ply==DMAX-4&&n<=alpha-900)                
	      futile=1;      
	  if (futile) all_moves_lose=0;
	  for (p=(ply<<7);p<=l;p++)      
	      {            
	      p1=gnextbest(l);               
	      if (futile&&unlikelycheck(b[plyf[p1]],plyt[p1],bkp))                    
		  continue;
	       if (hf && plyf[p1]==hf && plyt[p1]==ht)
		    continue;

	  if (plyf[p1]==hack_from && plyt[p1]==hack_to)
		    continue;
	  
	  FWMAKEMOVE(p1);
	  
	  if (ply<=DMAX-3&&!ic[ply]&&hist[plyf[p1]][plyt[p1]]<9500&&p>((ply<<7)+1)&&!(alpha == root_alpha && beta == root_beta)) 
	  {
          int R=1;

	  if (hist[plyf[p1]][plyt[p1]]<1600) R++;

	  DMAX-=R;
	  t=b_search(beta,alpha,n);
	  DMAX+=R;
	  if (t>alpha) t=b_search(beta,alpha,n);
	  }
	  else
	  t=b_search(beta,alpha,n);

	  /*
	       if (killerfrom[ply] && plyf[p1]==killerfrom[ply] && plyt[p1]==killerto[ply])
		    continue;

	  if (plyf[p1]==hack_from && plyt[p1]==hack_to)
	      {
	      printf("(W) Waste: %d ply\n", DMAX-ply);
	      }
	  */
	              
	 if (all_moves_lose)
	     if (!fastgenlbcheck(wkp))
		 all_moves_lose=0;

	       FWUNMAKEMOVE(p1);
	       if (t>alpha) {alpha=t;
				killerfrom[ply]=mpf;
				killerto[ply]=mpt;
				hist[mpf][mpt]+=histval[DMAX-ply]; 
				if (hist[mpf][mpt]>maxhist) clear_hist_table();
				if (t>=beta) {/* printf("[WN]"); */storepos(hash_board, mpf,mpt, oldalpha, beta, alpha); ply--; DMAX-=ext; return(alpha);}
				pc(mpf,mpt);
				bf=mpf;
				bt=mpt;
				}
	       if (STOP) break;
	  }
	}

     if (!ic[ply]&&end_game)
	 {
	 t=deaddraw();
#if DEBUG
         if (t) printboard();
         #endif
	 if (t==EXACT)
	     {
	     ply--;
	     return(0);
	     }
         if (t==UPPER_BOUND) /* at most for CPU */
	     {
             if (alpha>0)
                alpha=0;
             }
         if (t==LOWER_BOUND) /* at least for CPU */
	     {
             if (alpha<0)
                alpha=0;
	     }
	 }




#if STALEDETECT
if (all_moves_lose && ply<DMAX && !ic[ply])
    {
    /*
    if (beta<0)
	alpha=beta;
    else
    if (alpha<0)
	alpha=0;
    */
    alpha=0;
    ply--;
    DMAX-=ext;
    return(alpha);
    }
#endif

     if (alpha!=oldalpha)
     storepos(hash_board, bf,bt, oldalpha, beta, alpha);
     else
     storepos(hash_board,0,0,oldalpha,beta,alpha);
     ply--;
     DMAX-=ext;
     return(alpha);
}


static void rkiller(n)
int n;
{
	int t,t1,t2,t3,t4;
	for (t=(ply<<7);t<=n;t++)
		{
			if ((plyf[t]==killerfrom[ply])
				&& (plyt[t]==killerto[ply]))
					{
					o[t]=1000;
					t1=plyf[(ply<<7)]; t2=plyt[(ply<<7)]; t3=o[(ply<<7)]; t4=root[(ply<<7)];
					plyf[(ply<<7)]=plyf[t];
					plyt[(ply<<7)]=plyt[t];
					o[(ply<<7)]=o[t];
					root[(ply<<7)]=root[t];
					plyf[t]=t1;
					plyt[t]=t2;
					o[t]=t3;
					root[t]=t4;
					}
		}
}

/* principal cont */
static void pc(from, to)
/* char from, to; */
int from, to;
{
int j;

/*
for (i=0; i<=ply; i++)
    if (null[i])
	return;
*/
/*
if (!from)
    return;
*/

/*
if (ply>=OMAX)
    return;
*/

i=OMAX-ply;
pcf[ply][ply]=from;
pct[ply][ply]=to;
/* if (ply==DMAX) return; */
for (j=1;j<=i;j++)
	{
	pcf[ply][ply+j]=pcf[ply+1][ply+j];
	pct[ply][ply+j]=pct[ply+1][ply+j];
	}
/*
printf("\n");
for (i=1; i<5; i++)
    {
    for (j=1; j<5; j++)
	printf("%s ",toalg(pcf[i][j],pct[i][j]));
    printf("\n");
    }
*/
}


static void feedover(n)
int n;
{
	for (i=1;i<=n;i++)
		{
			killerfrom[i]=pcf[1][i];
			killerto[i]=pct[1][i];
		}

}

static void kingattack( )
{
	int kp;
	for (i=21;i<100;i++)
	{
	if (b[i]==BK) {kp=i; break;}
	}

	for (i=21;i<100;i++)
	{
	ka[i]=c[i]+(kdist(i,kp));
	}
}

setkd()
{
int a,b;

for (a=21; a<99; a++)
    {
    for (b=21; b<99; b++)
	{
	kd[a][b]=kdist(a,b);
	}
    }
}

static int kdist(p1,p2)
int p1,p2;
{
int x1,x2,y1,y2;

x1=p1%10;
y1=p1-x1;
y1/=10;

x2=p2%10;
y2=p2-x2;
y2/=10;

sc=(abs(x1-x2)+abs(y1-y2));
sc=15-sc;
sc*=2;
return(sc);
}

static void swapoff(bs)
int *bs;
{
int h,m,t;
long int temp;
m=h=0;
v[BP]=105;v[BR]=685;v[BN]=425;v[BB]=435;v[BQ]=1240;v[BK]=10000;

for (i=21;i<100;i++)
{
if (b[i]&START_WHITE_PIECES) m=m+v[b[i]];
if (b[i]&START_BLACK_PIECES) h=h+v[b[i]];
}

m=m-19999;
h=h-9999;

/* swap pieces, not pawns when ahead, and pawns not pieces when
   behind */

for (i=BP+1;i<END_BLACK_PIECES;i++)
{
t=v[i];
/* Fix for moving over to PCs */
temp=(long)v[i]*(long)m;
temp=temp/(h+0/*  300 */);
v[i]=temp;
v[i]=(v[i]+t)/2;
v[i]=(v[i]+t)/2;
}


/* printf ("Human material %d Machine material %d\n",h,m); */
/* printf ("Black's rook is now worth %d Bishop %d\n",v[BR],v[BB]); */
*bs=m-h;
}

char gamepos[512][80];
static int pos=0;

static void storeboard()
{
char s[1000];
char ts[10];
int last=0;
strcpy(s,"%\0");
for (i=21;i<99;i++)
	if ((b[i]!=0)&&(b[i]!=OFF_BOARD))
		{
		sprintf(ts,"%d",i-last);
		strcat(s,ts);
		sprintf(ts,"%c",64+b[i]);
		strcat(s,ts);
		last=i;
		}
pos++;
strcpy(gamepos[pos],s);
if (pos>500)
    {
    for (i=1; i<pos; i++)
	strcpy(gamepos[i], gamepos[i+1]);
    pos=500;
    }
}

static int occurred_before()
{
char s[1000];
char ts[10];
int last=0;
int times=0;

strcpy(s,"%\0");
for (i=21;i<99;i++)
	if ((b[i]!=0)&&(b[i]!=OFF_BOARD))
		{
		sprintf(ts,"%d",i-last);
		strcat(s,ts);
		sprintf(ts,"%c",64+b[i]);
		strcat(s,ts);
		last=i;
		}
for (i=pos-1; i>pos-128 && i>=0; i--)
    if (strcmp(gamepos[i],s)==0)
	times++;
return(times);
}

static void undo_last_move()
{
pos--;
if (pos<1)
    {
    pos++;
    fprintf(stdout, "couldn't undo a move - at start of game\n");
    return;
    }
else
    {
    int t;

    /* reset time pot - safety */

    /* time_pot=0; */

    /* blank out board */
    for (i=21; i<99; i++)
	if (b[i]!=OFF_BOARD)
	    b[i]=0;

    i=0;

    for (t=1; t<strlen(gamepos[pos]); t++)
	{
	if (isalpha(gamepos[pos][t]))
	    {
	    b[i]=gamepos[pos][t]-64;
	    }
	else
	    {
	    int n_blanks=gamepos[pos][t]-'0';
	    if (isdigit(gamepos[pos][t+1]))
		{
		t++;
		n_blanks=(n_blanks*10)+(gamepos[pos][t]-'0');
		}
	    i+=n_blanks;
	    }
	}

    }

if (BACKGROUND)
    {
    BACKGROUND=0;
    printboard();
    BACKGROUND=1;
    }
else
    {
    printboard();
    }
/* remember to move back move counter, too */
g--;
/* update which moves are legal.. */
do_opp_legal();
}

static int ob()
{
char s[1000];
char ts[10];
int last=0;
strcpy(s,"%\0");
for (i=21;i<99;i++)
	if ((b[i]!=0)&&(b[i]!=OFF_BOARD))
		{
		sprintf(ts,"%d",i-last);
		strcat(s,ts);
		sprintf(ts,"%c",64+b[i]);
		strcat(s,ts);
		last=i;
		}
/* printf("BOARD COMPRESSED AS :-\n%s\n",s); */
return(checkbook(s));
}

static int checkbook(pos)
char pos[999];
{
char line[999];
FILE *fp;
int ok=0;
int p1,p2;
long total_pos=0;
int numpos;

srand ((unsigned int)time(NULL)%32761);
/* printf ("time % 32761 is %d\n",time(NULL)%32761); */
/* srand(-1); */

bp=0;
if (colour==WHITE)
    fp=fopen("franbook.w","r");
else
    fp=fopen("franbook.b","r");
if (fp==0) {printf("\n NO BOOK!\n"); BOOK=0; return(0);}
create_hash_for_board();
printf("hash is %ld\n",hash_board);
printf("OPENED\n");
while ((fgets(line,999,fp))!=NULL)
	{
	/* if (strcmp(hash_board,line)==0) */
	/* printf("%ld %ld\n",atol(line),hash_board);*/
	total_pos++;
	if (atol(line)==(long)hash_board)
		{
		fgets(line,999,fp);
		fromalg(line,&p1,&p2);
		if (p1<10) p1+=128;
		if (p2<10) p2+=128;

		fgets(line,999,fp);
		numpos=atoi(line);
		/* fprintf(stdout, "numpos is %d\n",numpos); */
		for (i=1; i<=numpos; i++)
		    {
					ok++;
		    storeabookmove(p1,p2);
		    }
		}
	else
		{
		fgets(line,999,fp);
	fgets(line,999,fp);     
	}
	}
fclose(fp);

/* printf("Total positions in book = %ld\n", total_pos); */

if (ok==0)
    {
#ifdef DEBUG
    fprintf(stdout, "NOT found in book!\n");
#endif
    BOOK--;
    return(0);
    }
else
    {
#ifdef DEBUG
    fprintf(stdout,"FOUND IN BOOK....\n");
#endif
    if (ok<3)
	{
	/* fprintf(stdout,"less than three lines found. searching instead..\n"); */
	BOOK--;
	return(0);
	}
    getabookmove(&p1,&p2);
    ply1f=p1; ply1t=p2;
    lastbookmove=g;
	return(1);
    }
}

int bookf[65536+65536], bookt[65536+65536];

storeabookmove(p1,p2)
int p1,p2;
{
bookf[bp]=p1;
bookt[bp]=p2;
bp++;
}

getabookmove(p1,p2)
int *p1, *p2;
{
int t;

printf("Choosing one move from %d\n",bp);
#ifdef TOURN
printf("(Tournament mode)\n");
if (colour==WHITE)
    {
    *p1=bookf[0];
    *p2=bookt[0];
    }
if (colour==BLACK)
    {
    *p1=bookf[bp-1];
    *p2=bookt[bp-1];
    }
return;
#endif

t=(rand()%(bp));

printf("move chosen is %d out of %d\n",t,bp);

*p1=bookf[t];
*p2=bookt[t];

#if 0
if (colour==WHITE && g==1)
     {
     printf("always play e4 rule\n");
     *p1=35;
     *p2=55;
     }

if (colour==BLACK && g==1 && b[65]==BP)
     {
     printf("always play d5 rule\n");
     *p1=35;
     *p2=55;
     }
#endif

}

int * orig=&o[0];

static int gnextbest(n)
int n;
{
register int *p=&o[(ply<<7)], *bf;
int best=-16384,bestfound;

o[n+1]=0x7FFFFFFF;
for (;;p++)
    {
    if (*p>best)
	{
	if (*p==0x7FFFFFFF) break;
	best=*p;
	bf=p;
	}
    }

bestfound=(bf-orig);
o[bestfound]=-32768;
return(bestfound);
}

static void makecastle(castle)
int castle;
{
if (castle==MACHINE_CASTLE_W_K)
	{
	wsq[20]=25;
	wsq[21]=28;
	wupdatelist(25,27);
	wupdatelist(28,26);
	b[25]=b[28]=0;
	b[27]=WK;
	b[26]=WR;
	}
if (castle==MACHINE_CASTLE_B_K)
	{
	wsq[20]=24;
	wsq[21]=21;
	wupdatelist(24,22);
	wupdatelist(21,23);
	b[24]=b[21]=0;
	b[22]=WK;
	b[23]=WR;
	}

if (castle==MACHINE_CASTLE_W_Q)
	{
	wsq[20]=25;
	wsq[21]=21;
	wupdatelist(25,23);
	wupdatelist(21,24);
	b[21]=b[25]=0;
	b[23]=WK;
	b[24]=WR;
	}

if (castle==MACHINE_CASTLE_B_Q)
	{
	wsq[20]=24;
	wsq[21]=28;
	wupdatelist(24,26);
	wupdatelist(28,25);
	b[24]=b[28]=0;
	b[25]=WR;
	b[26]=WK;
	}
}

static void unmakecastle(castle)
int castle;
{
if (castle==MACHINE_CASTLE_W_K)
	{
	wsq[20]=27;
	wsq[21]=26;
	wupdatelist(27,25);
	wupdatelist(26,28);
	b[26]=b[27]=0;
	b[28]=WR;
	b[25]=WK;
	}
if (castle==MACHINE_CASTLE_B_K)
	{
	wsq[20]=22;
	wsq[21]=23;
	wupdatelist(22,24);
	wupdatelist(23,21);
	b[22]=b[23]=0;
	b[21]=WR;
	b[24]=WK;
	}
if (castle==MACHINE_CASTLE_W_Q)
	{
	wsq[20]=23;
	wsq[21]=24;
	wupdatelist(23,25);
	wupdatelist(24,21);
	b[24]=b[23]=0;
	b[21]=WR;
	b[25]=WK;
	}
if (castle==MACHINE_CASTLE_B_Q)
	{
	wsq[20]=25;
	wsq[21]=26;
	wupdatelist(26,24);
	wupdatelist(25,28);
	b[26]=b[25]=0;
	b[28]=WR;
	b[24]=WK;
	}
}

static int cancastle(castle)
int castle;
{
if (castle==MACHINE_CASTLE_W_K)
	{
	if ((b[25]==WK)&&(b[26]==0)&&(b[27]==0)&&(b[28]==WR))
		{
		ply++;
		genlegalblackcap();
		ply--;
		if (wch) return(0);
		wkp=26;
		b[26]=WK;
		ply++;
		genlegalblackcap();
		wkp=25;
		ply--;
		b[26]=0;
		if (wch) return(0);
		wkp=27;
		b[27]=WK;
		ply++;
		genlegalblackcap();
		wkp=25;
		ply--;
		b[27]=0;
		if (wch) return(0);
		return(1);
		}
	}
if (castle==MACHINE_CASTLE_B_K)
	{
	if ((b[24]==WK)&&(b[23]==0)&&(b[22]==0)&&(b[21]==WR))
		{
		ply++;
		genlegalblackcap();
		ply--;
		if (wch) return(0);
		wkp=23;
		b[23]=WK;
		ply++;
		genlegalblackcap();
		wkp=24;
		ply--;
		b[23]=0;
		if (wch) return(0);
		wkp=22;
		b[22]=WK;
		ply++;
		genlegalblackcap();
		wkp=24;
		ply--;
		b[22]=0;
		if (wch) return(0);
		return(1);
		}
	}
if (castle==MACHINE_CASTLE_W_Q)
	if ((b[25]==WK)&&(b[24]==0)&&(b[23]==0)&&(b[22]==0)&&(b[21]==WR))
	    {
	    ply++;
	    genlegalblackcap();
	    ply--;
	    if (wch) return(0);
	    wkp=24;
	    b[24]=WK;
	    ply++;
	    genlegalblackcap();
	    wkp=25;
	    ply--;
	    b[24]=0;
	    if (wch) return(0);
	    wkp=23;
	    b[23]=WK;
	    ply++;
	    genlegalblackcap();
	    wkp=25;
	    ply--;
	    b[23]=0;
	    if (wch) return(0);
	    return(1);
	    }
if (castle==MACHINE_CASTLE_B_Q)
	if ((b[24]==WK)&&(b[25]==0)&&(b[26]==0)&&(b[27]==0)&&(b[28]==WR))
	    {
	    ply++;
	    genlegalblackcap();
	    ply--;
	    if (wch) return(0);
	    wkp=25;
	    b[25]=WK;
	    ply++;
	    genlegalblackcap();
	    wkp=24;
	    ply--;
	    b[25]=0;
	    if (wch) return(0);
	    wkp=26;
	    b[26]=WK;
	    ply++;
	    genlegalblackcap();
	    wkp=24;
	    ply--;
	    b[26]=0;
	    if (wch) return(0);
	    return(1);
	    }
return(0);
}



static void calcsquares( )
{
int i1=0,i2=0;
for (i=98;i>20;i--)
	{
	if (b[i]&START_WHITE_PIECES)
		{
		if (b[i]==WK) wkp=i;
		wsq[i1]=i;
		i1++;
		}
	}

for (i=21;i<99;i++)
	{
	if (b[i]&START_BLACK_PIECES)
		{
		if (b[i]==BK) bkp=i;
		bsq[i2]=i;
		i2++;
		}
	}
wsq[i1]=bsq[i2]=-1;
lwp=&wsq[i1];
lbp=&bsq[i2];
}

static void bupdatelist(f,t)
int f,t;
{
register int *p;

/*
if (b[bkp]!=BK)
    {
    printf("\nerror here! bkp = %d\n",bkp);
    printf("ply = %d DMAX = %d\n",ply,DMAX);
    printboard();
    myexit(0);
    }
*/
	p=&bsq[0];
	for (;;)
		{
		if (*p==f)
			{if (f==bkp) bkp=t; *p=t; return;}
		p++;
		}
}


static void wupdatelist(f,t)
int f,t;
{
register int *p;
	p=&wsq[0];
	for (;;)
		{
		if (*p==f)
			{if (f==wkp) wkp=t; *p=t; return;}
		p++;
		}
}


    /*
    printf("cpos[ply] is %d\n",cpos[ply]);
    printf("sq is %d\n",sq);
    printf("b[cpos[ply]] is %d\n",b[cpos[ply]]);
    printf("poss[b[cpos[ply]]] is %d\n",poss[b[cpos[ply]]]);
    printf("poss check by piece %d\n", cpos[ply]);
    printboard();
    myexit(0);
    */

static int unlikelycheck(piece,fr,to)
int piece, fr, to;
{
if (poss[piece][fr][to])
    return(0);
else
    return(1);
}


static int fastgenlwcheck(sq)
int sq;
{
register int *p;
int delta, vector;

/* very fast check for check.. */
if (b[cpos[ply]]&START_WHITE_PIECES && poss[b[cpos[ply]]][cpos[ply]][sq])
    {
    switch (b[cpos[ply]])
	{
	    case WN: return(1);
	    case WP: return(1);
	    case WK: return(1);
	    case WB:
	    case WQ:
	    case WR: delta=128+(sq-cpos[ply]);
		     vector=diff[delta];
		     for (z=cpos[ply]+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    return(1);
			    }
			if (b[z]) break;
			}
		     break;
	}
    }

for (p=&wsq[0];p!=lwp;p++)
    {
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case WN: cpos[ply]=*p; return(1);
	    case WP: cpos[ply]=*p; return(1);
	    case WK: cpos[ply]=*p; return(1);
	    case WB:
	    case WQ:
	    case WR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    cpos[ply]=*p;
			    return(1);
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

return(0);
}

static int fastgenlwcheck_count(sq)
int sq;
{
register int *p;
int delta, vector;
int nat=0;

if (!fastgenlwcheck(sq))
    return(0);

for (p=&wsq[0];(p!=lwp);p++)
    {
    if (done[*p]) continue;
    done[*p]=1;
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case WN: cpos[ply]=*p; nat++; break;
	    case WP: cpos[ply]=*p; nat++; break;
	    case WK: cpos[ply]=*p; nat++; break;
	    case WB:
	    case WQ:
	    case WR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    cpos[ply]=*p;
			    nat++;
			    break;
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

for (p=&wsq[0];(p!=lwp);p++)
    done[*p]=0;


return(nat);
}

static int genlegalwhitecapsq(sq)
int sq;
{
register int *p;
int delta, vector;
int nat=0;


nw=ply<<7;
bch=0;

for (p=&wsq[0];(p!=lwp);p++)
    {
    if (done[*p]) continue;
    done[*p]=1;
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case WN: plyf[nw]=*p; plyt[nw]=sq; o[nw]=mvvlva[b[*p]][b[sq]]; nw++; break;
	    case WP: plyf[nw]=*p; plyt[nw]=sq; o[nw]=mvvlva[b[*p]][b[sq]]; nw++; break;
	    case WK: plyf[nw]=*p; plyt[nw]=sq; o[nw]=mvvlva[b[*p]][b[sq]]; nw++; break;
	    case WB:
	    case WQ:
	    case WR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    plyf[nw]=*p; plyt[nw]=sq; o[nw]=mvvlva[b[*p]][b[sq]]; nw++; break;
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

for (p=&wsq[0];(p!=lwp);p++)
    done[*p]=0;

nw--;

if (nw>=ply<<7&&sq==bkp)
    bch=1;

#if 0
if (nw>=ply<<7)
    {
#if 0
    printf ("ply is %d DMAX is %d sq is %d\n",ply,DMAX,sq);
    for (i=ply<<7;i<=nw;i++)
	printf("%s %d\n",toalg(plyf[i],plyt[i]),o[i]);
    printboard();
#endif
    for (i=ply<<7;i<=nw;i++)
	if (plyt[i]==bkp) bch=1;
    }
#endif
}



static int fastgenlbcheck(sq)
int sq;
{
register int *p;
int delta, vector;

/* very fast check for check.. */
if (b[cpos[ply]]&START_BLACK_PIECES && poss[b[cpos[ply]]][cpos[ply]][sq])
    {
    switch (b[cpos[ply]])
	{
	    case BN: return(1);
	    case BP: return(1);
	    case BK: return(1);
	    case BB:
	    case BQ:
	    case BR: delta=128+(sq-cpos[ply]);
		     vector=diff[delta];
		     for (z=cpos[ply]+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    return(1);
			    }
			if (b[z]) break;
			}
		     break;
	}
    }



for (p=&bsq[0];(p!=lbp);p++)
    {
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case BN: cpos[ply]=*p; return(1);
	    case BP: cpos[ply]=*p; return(1);
	    case BK: cpos[ply]=*p; return(1);
	    case BB:
	    case BQ:
	    case BR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    cpos[ply]=*p;
			    return(1);
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

return(0);
}

static int fastgenlbcheck_count(sq)
int sq;
{
register int *p;
int delta, vector;
int nat=0;

if (!fastgenlbcheck(sq))
    return(0);

for (p=&bsq[0];(p!=lbp);p++)
    {
    if (done[*p]) continue;
    done[*p]=1;
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case BN: cpos[ply]=*p; nat++; break;
	    case BP: cpos[ply]=*p; nat++; break;
	    case BK: cpos[ply]=*p; nat++; break;
	    case BB:
	    case BQ:
	    case BR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    cpos[ply]=*p;
			    nat++;
			    break;
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

for (p=&bsq[0];(p!=lbp);p++)
    done[*p]=0;

return(nat);
}


static int genlegalblackcapsq(sq)
int sq;
{
register int *p;
int delta, vector;
int nat=0;

nb=ply<<7;
wch=0;

for (p=&bsq[0];(p!=lbp);p++)
    {
    if (done[*p]) continue;
    done[*p]=1;
    if (poss[b[*p]][*p][sq])
	{
	switch (b[*p])
	    {
	    case BN: plyf[nb]=*p; plyt[nb]=sq; o[nb]=mvvlva[b[*p]][b[sq]]; nb++; break;
	    case BP: plyf[nb]=*p; plyt[nb]=sq; o[nb]=mvvlva[b[*p]][b[sq]]; nb++; break;
	    case BK: plyf[nb]=*p; plyt[nb]=sq; o[nb]=mvvlva[b[*p]][b[sq]]; nb++; break;
	    case BB:
	    case BQ:
	    case BR: delta=128+(sq-*p);
		     vector=diff[delta];
		     for (z=*p+vector;;z+=vector)
			{
			if (z==sq) 
			    {
			    plyf[nb]=*p; plyt[nb]=sq; o[nb]=mvvlva[b[*p]][b[sq]]; nb++; break;
			    }
			if (b[z]) break;
			}
		     break;
	    default: ;/* oops, piece has gone! */
	    }
	}
    }

for (p=&bsq[0];(p!=lbp);p++)
    done[*p]=0;

nb--;

#if 0
    printf ("ply is %d DMAX is %d sq is %d\n",ply,DMAX,sq);
    printboard();
    for (i=ply<<7;i<=nb;i++)
	printf("%s %d\n",toalg(plyf[i],plyt[i]),o[i]);
#endif



if (nb>=ply<<7&&sq==wkp)
    wch=1;

}



int global_ep, global_fp;
makeassumedmove()
{
promoteto=BQ; /* always ponder promotions to Q, nothing else */
ply2f=ply2t=0;
if (pcf[1][2])
    {
    ply2f=pcf[1][2];
    ply2t=pct[1][2];
    printf("picked assumed move %s from PV\n", toalg(ply2f, ply2t));
    }


/* fprintf(stdout, "ply is %d\n",ply); */

if (ply2f==0 || !check_if_legal_for_black(ply2f, ply2t))
    {
    int DMAXtmp=DMAX;

#ifdef WINBOARD
	BACKGROUND=0;
#endif

    DMAX=5;
    null[ply]=1; 
    STOP=0;
    (void) b_search(32000, -32000, 0);
    null[ply]=0; 
    clear_hash_table();
    clear_hist_table();
    ply2f=pcf[2][2];
    ply2t=pct[2][2];
    printf("picked assumed move %s from small search\n", toalg(ply2f, ply2t));
    if (!ply2f)
	{
	real_clear_hash_table();
	null[ply]=1; 
	STOP=0;
	(void) b_search(32000, -32000, 0);
	null[ply]=0; 
	ply2f=pcf[2][2];
	ply2t=pct[2][2];
	printf("picked assumed move %s from small search\n", toalg(ply2f, ply2t));
	}
    DMAX=DMAXtmp;
#ifdef WINBOARD
	BACKGROUND=1;
#endif
    }

if (ply2f)
    {
    global_ep=b[ply2t];
    global_fp=b[ply2f];
    if (global_fp==BK)
	bkp=ply2t;
    makemove(ply2f,ply2t);
    }

#if 0
#ifdef WINBOARD
if (1)
    {
    if (ply2f)
	{
	b[ply2f]=global_fp;
	b[ply2t]=global_ep;
	if (global_fp==BK)
	    bkp=ply2f;
	}

    ply2f=0;
    ply2t=0;
	return;
    }
#endif
#endif

if (BOOK || fastgenlwcheck(bkp))
    {
    if (BOOK)
	printf("(still in book - assuming nothing)\n");
    else
	printf("(illegal move assumed - assuming nothing)\n");
    
    if (ply2f)
	{
	b[ply2f]=global_fp;
	b[ply2t]=global_ep;
	if (global_fp==BK)
	    bkp=ply2f;
	}

    ply2f=0;
    ply2t=0;
    }
else
    fprintf(stdout,"Assumed %s\n",toalg(ply2f, ply2t));

fprintf(stdout,"\nPlease enter your move (or just enter to play %s)\n",toalg(ply2f,ply2t));
}

unmakeassumedmove()
{
if (ply2f)
    {
    b[ply2f]=global_fp;
    b[ply2t]=global_ep;
    
    if (global_fp==BK)
	bkp=ply2f;
    }
}

makebook()
{
FILE *fp, *in, * out;
char line[1000];

if (colour==WHITE)
    {
    if ((fp=fopen("book.w","r"))!=NULL)
	{
	fclose(fp);
	return;
	}
    }
else
    {
    if ((fp=fopen("book.b","r"))!=NULL)
	{
	fclose(fp);
	return;
	}
    }
in=fopen("book.txt","r");
if (in==NULL)
    {
    return;
    }
if (colour==WHITE)
    out=fopen("book.w","w");
else
    out=fopen("book.b","w");

if (out==NULL)
    {
    fclose(in);
    return;
    }
while (fgets(line,999,in)!=NULL)
    {
    if (line[0]=='!')
	setboard();
    else
	putrawpos(line,out);
    }

fclose(in);
fclose(out);
}

putrawpos(char * line, FILE * out)
{
int f,t,f1,t1,pnt;



if (colour==WHITE)
    {
    create_hash_for_board();
    fprintf(out, "%ld\n", (long)hash_board);
    /* outputboard(out); */
    fromalg(line,&f,&t);
    if (f<5)
	f+=MACHINE_CASTLES;
    makemove(f,t);
    pnt=0;
    while (line[pnt]!=' ') pnt++;
    while (line[pnt]==' ') pnt++;
    fromalg(line+pnt,&f1,&t1);
    makemove(f1,t1);
    pnt=0;
    while (line[pnt]!=' ') pnt++;
    line[pnt]='\0';
    fprintf(out,"%s\n",line);
    }


if (colour==BLACK)
    {
    fromalg(line,&f,&t);
    makemove(f,t);

    create_hash_for_board();
    /*
    printboard();
    printf("%ld\n",hash_board);
    */
    fprintf(out, "%ld\n", hash_board);
    pnt=0;
    while (line[pnt]!=' ') pnt++;
    while (line[pnt]==' ') pnt++;
    fromalg(line+pnt,&f1,&t1);
    if (f1<5)
	f1+=MACHINE_CASTLES;
    makemove(f1,t1);
    fprintf(out,"%s",line+pnt);
    }

}

outputboard(FILE *out)
{
int last=0;
char s[255], ts[255];
strcpy(s,"%\0");
for (i=21;i<99;i++)
	if ((b[i]!=0)&&(b[i]!=OFF_BOARD))
		{
		sprintf(ts,"%d",i-last);
		strcat(s,ts);
		sprintf(ts,"%c",64+b[i]);
		strcat(s,ts);
		last=i;
		}
fprintf(out,"%s\n",s);
}


static void showtitle( )
{
char input[64];

#ifndef WINBOARD

for (i=0;i<50;i++)
    printf("\n");


printf("***************************************\n");
printf("  Francesca (v%s) by T.King (c) 1997.\n",VERSION);
#ifdef WIN
printf("                                      \n");
printf("      (Windows/DOS Box Version)       \n");
printf("                                      \n");
#endif
printf("  Usage: fran [black]                  \n");
printf("***************************************\n\n\n\n\n\n\n\n");

#ifndef QMW
while (mykbhit()==0)
    ;
#ifdef WIN32
/* throw away char */
_getch();
#endif

#endif
#endif

#ifdef WINBOARD
colour=BLACK; setboard();

while(1)
{
gets(input);
if (strncmp(input,"level",5)==0)
    {
	char *p;

#if DEBUG
	fprintf(stdout, "got level command\n");
#endif

	p=&input[0];
	p+=6;
	sscanf(p,"%d",&moves_to_make);
	while (*p!=' '&&*p!='\0')
		p++;
	p++;
	sscanf(p,"%d",&mins);   

	if (!moves_to_make)
	    {
	    int extra;

#if DEBUG
	    fprintf(stdout, "hmmm. incremental clock? ok..\n"); 
#endif
	    moves_to_make=120;
	    while (*p!=' '&&*p!='\0')
		p++;
	    p++;
	    sscanf(p,"%d",&inc_clock_extra_secs);   
	    time_pot=mins*60;       
	    incremental=1;
	    }
	else
	    {
#if DEBUG
	    fprintf(stdout, "hmmm. standard clock? ok..\n");
	    fprintf(stdout, "ok. fran to make %d moves in %d mins\n",moves_to_make,mins);
#endif
	    /* time_pot=mins*60/moves_to_make*moves_to_make; */
	    time_pot=mins*60;
	    max_time=mins*60/moves_to_make;
	    incremental=0;
	    }
#if DEBUG
	fprintf(stdout, "starting time_pot is %f\n",time_pot);
#endif
	continue;
	}

if (strncmp(input,"quit",4)==0)
    {
	#if DEBUG
	fprintf(stdout, "got quit command\n");
	#endif
    exit(0);
    }

if (strncmp(input,"easy",4)==0)
    {
	#if DEBUG
	fprintf(stdout, "got easy command\n");
	#endif
	ponder=0;
	continue;
    }

if (strncmp(input,"hard",4)==0)
    {
	#if DEBUG
	fprintf(stdout, "got hard command\n");
	#endif
	ponder=1;
	continue;
    }

if (strncmp(input,"time",4)==0||strncmp(input,"otim",4)==0)
    {
	#if DEBUG
	fprintf(stdout, "got time/ otim command.. ignoring\n");
	#endif
    /* return; */
	continue;
    }

if (strcmp(input,"white")==0)
    {
	#if DEBUG
	fprintf(stdout, "got white command\n");
	#endif

	colour=BLACK; setboard();
	continue;
    }
if (strcmp(input,"black")==0)
    {
	#if DEBUG
	fprintf(stdout, "got black command\n");
	#endif

	colour=WHITE; setboard();
	continue;
    }
if (strcmp(input,"go")==0)
    {
	#if DEBUG
	fprintf(stdout, "got go command\n");
	#endif

	if (colour==WHITE)
		colour=BLACK; 
	else
		colour=WHITE;

	setboard();

#if DEBUG
	fprintf(stdout,"go command issued.. colour is %d..\n",colour);
#endif

	return;
    }

	calcsquares();
	do_opp_legal();
	storeboard();

	fromalg(input, &humanfrom,&humanto);
#if DEBUG
	fprintf(stdout, "a possible move %s (%d-%d)\n",input,humanfrom,humanto);
#endif
	if (is_legal())
	{
    #if DEBUG
	    fprintf(stdout,"got legal move %s..\n",input);
    #endif
	strcpy(gamescoreh[1],toalg(humanfrom,humanto));
	makemove(humanfrom, humanto);
	return;
	}
	else
	{
	#if DEBUG
	    fprintf(stdout,"got illegal move %s..\n",input);
    #endif
	}
}
#endif
}

static void genlegalwhitenoncap()
{
register int *p;
char input [64];
bch=0;
nw=(ply<<7);

for (p=&wsq[0];(p!=lwp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     switch (b[z])
	 {
	 case WP: wpawnnoncap(); break;
	 case WR: wrooknoncap(); break;
	 case WN: wknightnoncap(); break;
	 case WB: wbishopnoncap(); break;
	 case WQ: wqueennoncap(); break;
	 case WK: wkingnoncap(); break;
	 }
}
nw--;
for (p=&wsq[0];(p!=lwp);p++)
	done[*p]=0;
if (!BACKGROUND)
    {
	/* check if time is up */
	if (!qq)
	  {
	  clock_end=clock();
	  if (clock_end<clock_start)
	    {
	    printf("Clock() cycle detected - coping..\n");
	    clock_start=clock_end;
	    }
	  else
	    {
	    if (clock_end-clock_start>(CLOCKS_PER_SEC/10))
		{
		time_used+=(double)(clock_end-clock_start)/CLOCKS_PER_SEC;
		clock_start=clock_end;
#ifdef BRATKO
		if (time_used>(no_of_seconds))
		    STOP=1;

#else
		/*
		if (time_used>(time_pot/4)||time_used>max_time*2)
			STOP=1;
		*/
	    if (time_used>abs_max_time||time_used>max_time*2)
		    STOP=1;
#endif
		}
		}
	  }
	/* check for escape */
	if (!qq&&mykbhit()&&(getch()==27)&&!MAKINGASSUMEDMOVE)
	    {
	    printf("\nEscape - search aborted\n");
	    STOP=1;
	    }
	 qq+=16;
    }
else
    {
#ifdef QMW
    if (((clock()-last_poll)/CLK_TCK) > POLL_INTERVAL)
      {
      int move;
      last_poll=clock();
    if (!auto_readmove(&move))
	{
	fprintf(stdout,"\nPlease enter your move\n");
	fprintf(stdout,"Got a move %d\n",move);
	fromqmwformat(move,&humanfrom,&humanto);
	fprintf(stdout, "move is %d. humanfrom is %d. humanto is %d\n", move, humanfrom, humanto);
	if ((humanfrom==ply2f)&&(humanto==ply2t))
	    {
	    BACKGROUND=0;
	    g++;
	    clock_start=clock();
	    ply2f=pcf[1][2]; ply2t=pct[1][2];
	    }
	else
	    {
	    STOP=1;
	    }
	}
      }
#else
	
	if (mykbhit()&&!STOP&&!MAKINGASSUMEDMOVE)
	{
	while(1)
	      {
	      if (ply1f)
		  printf("\n>>>> My move was %s <<<<\n",toalg(lastmovef,lastmovet));
		  #ifdef WIN32
	      /* throw away char */
	      _getch();
	      #endif
	      /* printf("not pondering, no is %ld\n",no); */
		  /* fprintf(stdout,"Awaiting move from opposition\n"); */
		  gets(input);
		  /* fprintf(stdout, "entered was >>%s<<\n",input); */
	      /* scanf("%s",input); */
	      if (input[0]==0&&ply2f) 
		  {
		  strcpy(input, toalg(ply2f,ply2t));
		  fprintf(stdout,"You're playing %s? Ok..\n",toalg(ply2f,ply2t));
		  }
	      if (!strcmp(input, "undo")||!strcmp(input, "UNDO")||!strcmp(input, "remove")||!strcmp(input, "REMOVE"))
		  {
		  STOP=2;
		  return;
		  }
	      fromalg(input, &humanfrom,&humanto);
	      if (is_legal())
		  {
#ifdef DEBUG
		  fprintf(stdout,"g is %d\n",g);
#endif
		  if (colour==WHITE)
		      strcpy(gamescoreh[g-1],toalg(humanfrom,humanto));
		  else
		      strcpy(gamescoreh[g],toalg(humanfrom,humanto));
		  break;
		  }
	      else
		  {
		  #ifndef WINBOARD
		  if (humanfrom)
			  fprintf(stdout,"Fran says: Illegal!!\n");
		  #endif
		  }
	      }
/* if computer has predicted human's move correctly, AND */
/* the move is a normal move (i.e. not a weird promotion */
/* to a knight or something, AND enough time has elapsed */
/* AND we're not running Winboard with pondering off,    */
/* THEN make the move straight away..                    */
	if ((humanfrom==ply2f)&&(humanto==ply2t)&&promoteto==BQ)
	    {
/* computer has pondered human's move correctly */
	    BACKGROUND=0;
	    g++;

#ifndef WIN
	    if ((clock()-clock_start)/CLOCKS_PER_SEC>/* no_of_seconds */max_time)
		{

		fprintf(stdout,"making move straight away..\n");

		

#ifndef WINBOARD
		STOP=1;
#else
		/* if in winboard mode, and there's no pondering, don't make move straight away..*/
		if (ponder) STOP=1;
#endif
		}
#endif

	    clock_start=clock();
	    no=0;
#ifdef WINBOARD
		fprintf(stdout, "0 0 0 0 ?\n");
#endif
	    if (colour==WHITE)
		strcpy(gamescoreh[g-1],toalg(humanfrom,humanto));
	    else
		strcpy(gamescoreh[g],toalg(humanfrom,humanto));
	    time_used=0;
	    ply2f=pcf[1][2]; ply2t=pct[1][2];
	    }
	else
	    {
	    STOP=1;
	    }
	}
#endif
    }

}

static void wpawnnoncap( )
{
if (z<80) /* don't generate queening moves.. (done as captures) */
{
i=z+10;
if (!b[i])
    {
    dowhite();
    if (z<39)
	{
	i=z+20;
	if (!b[i]&&(b[i-1]!=BP&&b[i+1]!=BP)) dowhite();
	}
    }
}
}

static void wrooknoncap( )
{
for (i=z+10;;i+=10)
    if (b[i]) break;
    else dowhite();

for (i=z+1;;i++)
    if (b[i]) break;
    else dowhite();

for (i=z-1;;i--)
    if (b[i]) break;
    else dowhite();

for (i=z-10;;i-=10)
    if (b[i]) break;
    else dowhite();
}


static void wbishopnoncap( )
{
for(i=z+11;;i+=11)
    if (b[i]) break;
    else dowhite();

for(i=z-9;;i-=9)
    if (b[i]) break;
    else dowhite();

for(i=z-11;;i-=11)
    if (b[i]) break;
    else dowhite();

for(i=z+9;;i+=9)
    if (b[i]) break;
    else dowhite();
}

static void wqueennoncap( )
{
wrooknoncap();
wbishopnoncap();
}

static void wknightnoncap( )
{
i=z+8;
if (!b[i]) dowhite();
i=z-8;
if (!b[i]) dowhite();
i=z+12;
if (!b[i]) dowhite();
i=z-12;
if (!b[i]) dowhite();
i=z+19;
if (!b[i]) dowhite();
i=z-19;
if (!b[i]) dowhite();
i=z+21;
if (!b[i]) dowhite();
i=z-21;
if (!b[i]) dowhite();
}

static void wkingnoncap( )
{
i=z+9;
if (!b[i]) dowhite();
i=z+10;
if (!b[i]) dowhite();
i=z+11;
if (!b[i]) dowhite();
i=z+1;
if (!b[i]) dowhite();
i=z-9;
if (!b[i]) dowhite();
i=z-10;
if (!b[i]) dowhite();
i=z-11;
if (!b[i]) dowhite();
i=z-1;
if (!b[i]) dowhite();
}

static void genlegalblacknoncap()
{
register int *p;
wch=0;
nb=(ply<<7);

for (p=&bsq[0];(p!=lbp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     switch (b[z])
	 {
	 case BP: bpawnnoncap(); break;
	 case BR: brooknoncap(); break;
	 case BN: bknightnoncap(); break;
	 case BB: bbishopnoncap(); break;
	 case BQ: bqueennoncap(); break;
	 case BK: bkingnoncap(); break;
	 }
}
nb--;
for (p=&bsq[0];(p!=lbp);p++)
	done[*p]=0;
}

static void bpawnnoncap( )
{
if (z>40)
{
i=z-10;
if (!b[i])
    {
    doblack();
    if (z>80)
	{
	i=z-20;
	if (!b[i]) doblack();
	}
    }
}
}

static void brooknoncap( )
{
for (i=z+10;;i+=10)
    if (b[i]) break;
    else doblack();

for (i=z+1;;i++)
    if (b[i]) break;
    else doblack();

for (i=z-1;;i--)
    if (b[i]) break;
    else doblack();

for (i=z-10;;i-=10)
    if (b[i]) break;
    else doblack();
}


static void bbishopnoncap( )
{
for(i=z+11;;i+=11)
    if (b[i]) break;
    else doblack();

for(i=z-9;;i-=9)
    if (b[i]) break;
    else doblack();

for(i=z-11;;i-=11)
    if (b[i]) break;
    else doblack();

for(i=z+9;;i+=9)
    if (b[i]) break;
    else doblack();
}

static void bqueennoncap( )
{
brooknoncap();
bbishopnoncap();
}

static void bknightnoncap( )
{
i=z+8;
if (!b[i]) doblack();
i=z-8;
if (!b[i]) doblack();
i=z+12;
if (!b[i]) doblack();
i=z-12;
if (!b[i]) doblack();
i=z+19;
if (!b[i]) doblack();
i=z-19;
if (!b[i]) doblack();
i=z+21;
if (!b[i]) doblack();
i=z-21;
if (!b[i]) doblack();
}

static void bkingnoncap( )
{
i=z+9;
if (!b[i]) doblack();
i=z+10;
if (!b[i]) doblack();
i=z+11;
if (!b[i]) doblack();
i=z+1;
if (!b[i]) doblack();
i=z-9;
if (!b[i]) doblack();
i=z-10;
if (!b[i]) doblack();
i=z-11;
if (!b[i]) doblack();
i=z-1;
if (!b[i]) doblack();
}



static void genlegalwhitecap()
{
register int *p;
bch=0;
nw=(ply<<7);

for (p=&wsq[0];(p!=lwp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     switch (b[z])
	 {
	 case WP: wpawncap(); break;
	 case WR: wrookcap(); break;
	 case WN: wknightcap(); break;
	 case WB: wbishopcap(); break;
	 case WQ: wqueencap(); break;
	 case WK: wkingcap(); break;
	 }
if (bch) break;
}
nw--;
for (p=&wsq[0];(p!=lwp);p++)
	done[*p]=0;
}

static void wpawncap()
{
i=z+11;
takewhite();
i=z+9;
takewhite();
if (z>80)
	{
	i=z+10;
	if (!b[i])
	    {
	    dowhite();
	    o[nw-1]=26900;
	    }
	}
}

static void wrookcap()
{
for (i=z+10;!b[i];i+=10)
    ;
takewhite();

for (i=z+1;!b[i];i++)
    ;
takewhite();

for (i=z-1;!b[i];i--)
    ;
takewhite();

for (i=z-10;!b[i];i-=10)
    ;
takewhite();    
}


static void wbishopcap()
{
for(i=z+11;!b[i];i+=11)
    ;
takewhite();

for(i=z-9;!b[i];i-=9)
    ;
takewhite();

for(i=z-11;!b[i];i-=11)
    ;
takewhite();

for(i=z+9;!b[i];i+=9)
    ;
takewhite();
}

static void wqueencap()
{
wrookcap();
wbishopcap();
}

static void wknightcap()
{
i=z+8;
takewhite();
i=z-8;
takewhite();
i=z+12;
takewhite();
i=z-12;
takewhite();
i=z+19;
takewhite();
i=z-19;
takewhite();
i=z+21;
takewhite();
i=z-21;
takewhite();
}

static void wkingcap()
{
i=z+9;
takewhite();
i=z+10;
takewhite();
i=z+11;
takewhite();
i=z+1;
takewhite();
i=z-9;
takewhite();
i=z-10;
takewhite();
i=z-11;
takewhite();
i=z-1;
takewhite();
}

static void genlegalblackcap()
{
register int *p;
wch=0;
nb=(ply<<7);
for (p=&bsq[0];(p!=lbp);p++)
{
z=*p;
if (done[z]) continue;
     done[z]=1;
     switch (b[z])
	 {
	 case BP: bpawncap(); break;
	 case BR: brookcap(); break;
	 case BN: bknightcap(); break;
	 case BB: bbishopcap(); break;
	 case BQ: bqueencap(); break;
	 case BK: bkingcap(); break;
	 }
if (wch) break;
}
nb--;

for (p=&bsq[0];(p!=lbp);p++)
	done[*p]=0;
}

static void bpawncap()
{
i=z-9;
takeblack();
i=z-11;
takeblack();
if (z<40)
	{
	i=z-10;
	if (!b[i])
	    {
	    doblack();
	    o[nb-1]=26900;
	    }
	}
}

static void brookcap()
{
for (i=z+10;!b[i];i+=10)
    ;
takeblack();

for (i=z+1;!b[i];i++)
    ;
takeblack();

for (i=z-1;!b[i];i--)
    ;
takeblack();

for (i=z-10;!b[i];i-=10)
    ;
takeblack();
}

static void bbishopcap()
{
for (i=z+11;!b[i];i+=11)
    ;
takeblack();

for (i=z-9;!b[i];i-=9)
    ;
takeblack();

for (i=z-11;!b[i];i-=11)
    ;
takeblack();

for (i=z+9;!b[i];i+=9)
    ;
takeblack();
}

static void bqueencap()
{
brookcap();
bbishopcap();
}

static void bknightcap()
{
i=z+8;
takeblack();
i=z-8;
takeblack();
i=z+12;
takeblack();
i=z-12;
takeblack();
i=z+19;
takeblack();
i=z-19;
takeblack();
i=z+21;
takeblack();
i=z-21;
takeblack();
}

static void bkingcap()
{
i=z+9;
takeblack();
i=z+10;
takeblack();
i=z+11;
takeblack();
i=z+1;
takeblack();
i=z-9;
takeblack();
i=z-10;
takeblack();
i=z-11;
takeblack();
i=z-1;
takeblack();
}



#ifdef BRATKO
dobratko()
{
int j,k,col,p;
char pos[77][8];
FILE* fp;
char temp[256],s[256];
int copy[143];
int fs=0;

/* bt results */
for (k=1; k<75; k++)
    strcpy(pos[k],"xxxx");
g=20;
for (k=50; k<99; k++)
    {
    j=k;
    if (j>9)
/*       sprintf(temp,"bratko\\bk0%d",j);  */
	    sprintf(temp,"bt\\bt0%d",j); 
else
	   /*  sprintf(temp,"bratko\\bk00%d",j);   */
	       sprintf(temp,"bt\\bt00%d",j); 
    printf("temp is %s\n",temp);
    fp=fopen(temp,"r");
    if (fp==NULL)
	{
	fprintf(stderr,"Can't read %s\n",temp);
	exit(0);
	}
    fgets(s,255,fp);
    if ((strstr(s,"o move White")!=NULL))
	{
	colour=WHITE;
	}
    else
	{
	colour=BLACK;
	}
    while ((fgets(s,255,fp))!=NULL)
	{
	if ((isdigit(s[0])))
	    {
/*          printf("s is %s\n",s); */
	    for (i=2; i<10; i++)
		{
/* use this one for bratko */
/*                p=91-((s[0]-'0')*10)+i-2;    */
/* use this one for BT */
		p=11+((s[0]-'0')*10)+i-2;    
/*              printf("p is %d ",p); */
		switch(s[i])
		    {
		    case '.': b[p]=0;
			    break;
		    case 'r': b[p]=WR;
			    break;
		    case 'n': b[p]=WN;
			    break;
		    case 'b': b[p]=WB;
			    break;
		    case 'q': b[p]=WQ;
			    break;
		    case 'k': b[p]=WK;
			    break;
		    case 'p': b[p]=WP;
			    break;
		    case 'R': b[p]=BR;
			    break;
		    case 'N': b[p]=BN;
			    break;
		    case 'B': b[p]=BB;
			    break;
		    case 'Q': b[p]=BQ;
			    break;
		    case 'K': b[p]=BK;
			    break;
		    case 'P': b[p]=BP;
			    break;
		    }
		}
	    }
	}
	if (colour==BLACK)
		 {
		 /* swap round */
		 p=0;
		 for (i=21; i< 99; i++)
		     {
		     copy[98-p]=b[i];
		     p++;
		     }
		 for (i=21; i<99 ;i++)
		     {
		     switch(copy[i])
			 {
			 case BR: b[i]=WR; break;
			 case BN: b[i]=WN; break;
			 case BB: b[i]=WB; break;
			 case BQ: b[i]=WQ; break;
			 case BK: b[i]=WK; break;
			 case BP: b[i]=WP; break;
			 case WR: b[i]=BR; break;
			 case WN: b[i]=BN; break;
			 case WB: b[i]=BB; break;
			 case WQ: b[i]=BQ; break;
			 case WK: b[i]=BK; break;
			 case WP: b[i]=BP; break;
			 default: b[i]=copy[i]; break;
			 }
		     }
		 }
	printboard();
    g=20;
    fclose(fp);
    
    clear_hash_table(); 
    clear_hist_table();   
    create_hash_for_board();  

    /* loudeval(0); */
    start();
    printf("\n");
    printf("My move is %s \n",toalg(ply1f,ply1t));
    printf("Nodes = %ld\n",no);
    if ((strcmp(toalg(ply1f,ply1t),pos[j])==0))
	{
	printf("Right!\n");
	fs++;
	}
    else
	{
	printf("Wrong. Answer is %s\n",pos[j]);
	}
    }
printf("Program got total of %d correct\n",fs);
exit(0);
}
#endif


/* calculate all the legal moves for the opponent */
do_opp_legal()
{

/* safety - recalculate all squares */
calcsquares();

DMAX+=10;
genlegalblack();
n_leg=nb;
DMAX-=10;

for (i=ply<<7; i<=n_leg; i++)
    {
    legalf[i]=plyf[i];
    legalt[i]=plyt[i];
    }

    if ((b[95]==BK)&&(b[98]==BR)&&(b[96]==0)&&(b[97]==0))
	{
	legalf[i]=1;
	legalt[i]=1;
	i++;
	n_leg++;
	}
    if ((b[95]==BK)&&(b[91]==BR)&&(b[92]==0)&&(b[93]==0)&&(b[94]==0))
	{
	legalf[i]=2;
	legalt[i]=2;
	i++;
	n_leg++;
	}
    if ((b[94]==BK)&&(b[98]==BR)&&(b[97]==0)&&(b[96]==0)&&(b[95]==0))
	{
	legalf[i]=4;
	legalt[i]=4;
	i++;
	n_leg++;
	}
    if ((b[94]==BK)&&(b[91]==BR)&&(b[92]==0)&&(b[93]==0))
	{
	legalf[i]=3;
	legalt[i]=3;
	i++;
	n_leg++;
	}
}

is_legal()
{
int legal=0;

for (i=0; i<=n_leg; i++)
    {
#if 0
#if DEBUG
    fprintf(stdout,"%d %d %d %d\n",humanfrom,humanto,legalf[i],legalt[i]);
#endif
#endif
    if (legalf[i]&&legalf[i]==humanfrom&&legalt[i]==humanto)
	legal=1;
#ifdef WINBOARD
	if (legalf[i]==3&&humanfrom==94&&humanto==92)
	    legal=1;
	if (legalf[i]==4&&humanfrom==94&&humanto==96)
	    legal=1;
	if (legalf[i]==1&&humanfrom==95&&humanto==97)
	    legal=1;
	if (legalf[i]==4&&humanfrom==95&&humanto==93)
	    legal=1;
#endif
    }

#if 0
if (!legal)
  for (i=0; i<=n_leg; i++)
    {
    fprintf(stdout,"%d %d %d %d\n",humanfrom,humanto,legalf[i],legalt[i]); 
    }
#endif

return(legal);
}

static int check_if_legal_for_black(int from, int to)
{
int ok=0;

/* quick check for legality */
if (!(b[from]&START_BLACK_PIECES))
    return(0);
if (b[to]&START_BLACK_PIECES)
    return(0);

wch=0;
nb=(ply<<7);
z=from;
if (ply<DMAX)
switch(b[z])
    {
    case (BP): bpawn();  break;
    case (BR): brook();  break;
    case (BN): bknight();  break;
    case (BB): bbishop();  break;
    case (BQ): bqueen();  break;
    case (BK): bking();  break;
    }
else
switch(b[z])
    {
    case (BP): bpawncap();  break;
    case (BR): brookcap();  break;
    case (BN): bknightcap();  break;
    case (BB): bbishopcap();  break;
    case (BQ): bqueencap();  break;
    case (BK): bkingcap();  break;
    }


    for (i=(ply<<7);i<nb;i++)
	{
	if ((plyf[i]==from)
	  &&(plyt[i]==to))
	  {
	  ok=1;
	  break;
	  }
	}

return(ok);
}

static int check_if_legal_for_white(int from, int to)
{
int ok=0;

/* quick check for legality */
if (!(b[from]&START_WHITE_PIECES))
    return(0);
if (b[to]&START_WHITE_PIECES)
    return(0);

bch=0;
nw=(ply<<7);
z=from;
if (ply<DMAX)
switch(b[z])
    {
    case (WP): wpawn();  break;
    case (WR): wrook();  break;
    case (WN): wknight();  break;
    case (WB): wbishop();  break;
    case (WQ): wqueen();  break;
    case (WK): wking();  break;
    }
else
switch(b[z])
    {
    case (WP): wpawncap();  break;
    case (WR): wrookcap();  break;
    case (WN): wknightcap();  break;
    case (WB): wbishopcap();  break;
    case (WQ): wqueencap();  break;
    case (WK): wkingcap();  break;
    }


    for (i=(ply<<7);i<nw;i++)
	{
	if ((plyf[i]==from)
	  &&(plyt[i]==to))
	  {
	  ok=1;
	  break;
	  }
	}

return(ok);
}

static int check_if_legal_for_black_non_cap(int from, int to)
{
int ok=0;

/* quick check for legality */
if (!(b[from]&START_BLACK_PIECES))
    return(0);
if (b[to])
    return(0);

wch=0;
nb=(ply<<7);
z=from;
switch(b[z])
    {
    case (BP): bpawnnoncap();  break;
    case (BR): brooknoncap();  break;
    case (BN): bknightnoncap();  break;
    case (BB): bbishopnoncap();  break;
    case (BQ): bqueennoncap();  break;
    case (BK): bkingnoncap();  break;
    }


    for (i=(ply<<7);i<nb;i++)
	{
	if (plyt[i]==to)
	  {
	  ok=1;
	  break;
	  }
	}

return(ok);
}

static int check_if_legal_for_white_non_cap(int from, int to)
{
int ok=0;

/* quick check for legality */
if (!(b[from]&START_WHITE_PIECES))
    return(0);
if (b[to])
    return(0);

bch=0;
nw=(ply<<7);
z=from;
switch(b[z])
    {
    case (WP): wpawnnoncap();  break;
    case (WR): wrooknoncap();  break;
    case (WN): wknightnoncap();  break;
    case (WB): wbishopnoncap();  break;
    case (WQ): wqueennoncap();  break;
    case (WK): wkingnoncap();  break;
    }

    for (i=(ply<<7);i<nw;i++)
	{
	if (plyt[i]==to)
	  {
	  ok=1;
	  break;
	  }
	}

return(ok);
}

real_clear_hist_table()
{
int p,p1;

for (p=0; p<133; p++)
    for (p1=0; p1<133; p1++)
	{
	hist[p][p1]=0;
	}
}

clear_hist_table()
{
int p,p1;
int his=0;

#if LOUD
fprintf(stdout, "Tweaking history table..maxhist is %d\n",maxhist);
#endif
for (p=0; p<133; p++)
    for (p1=0; p1<133; p1++)
	{
	if (hist[p][p1]>his)
	    {
	    his=hist[p][p1];
	    }
#ifdef BRATKO
	hist[p][p1]=0;
#else
	hist[p][p1]/=2;
#endif
	}
#if LOUD
fprintf(stdout, "(hi hist was %d)\n",his);
#endif
his=0;
for (p=0; p<133; p++)
    for (p1=0; p1<133; p1++)
	{
	if (hist[p][p1]>his)
	    {
	    his=hist[p][p1];
	    }
	}
#if LOUD
fprintf(stdout,"(hi hist now %d)\n",his);
#endif

/* for(p=0; p<30; p++) 
    printf("%d ",histval[p]); */
}


calc_time()
{
	/* assume we always play for 32 more moves.. */
     if (incremental)
	 {
	 max_time=(time_pot/32);
	 /* max_time+=inc_clock_extra_secs; */
	 }
     else
         {
	     int moves_left=1;
	     if (g>1&&(g-1)%moves_to_make==0)
		 {
	        time_pot+=(mins*60);
            /* fprintf(stdout, "Wow! More time. Cool. time_pot is now %f\n",time_pot); */
		 }
         moves_left=moves_to_make-((g-1)%moves_to_make);
		 moves_left++;
         /* if (moves_left==0)
	        moves_left=1; */
#if DEBUG
	     fprintf(stdout, "g is %d moves_left is %d\n",g,moves_left);
#endif


		 /* fudge - pretend there's more moves left than there really are */
		 /* moves_left++; */
	     max_time=(time_pot/ moves_left);
         }
     /* fprintf(stdout, "max_time is %f time_pot is %f\n",max_time,time_pot); */
     if (BOOK)
	 {
		 max_time*=1.75;
		 /* fprintf(stdout, "Just out of book.. adjusted max_time to %f\n",max_time); */
	 }

     if (time_pot<16) max_time/=2;
     if (time_pot<8) max_time/=2;

     min_time=max_time*0.3333334;
     max_bad_time=max_time*2.5;
     max_lose_time=max_time*7;
     if (incremental)
	{
	abs_max_time=time_pot/4;
	}
     else
	{
	abs_max_time=time_pot/4;
	}
	 if (min_time>abs_max_time) min_time=abs_max_time;
	 if (max_time>abs_max_time) max_time=abs_max_time;
     if (max_bad_time>abs_max_time) max_bad_time=abs_max_time;
     if (max_lose_time>abs_max_time) max_lose_time=abs_max_time;

#if DEBUG
     fprintf(stdout, "min_time is %f max_time is %f max_bad_time is %f max_lose_time is %f time_pot is %f\n",min_time,max_time,max_bad_time,max_lose_time,time_pot);
#endif
}

/* check for a dead draw..*/
int deaddraw()
{
int w_queen=0,w_rook=0,w_knight=0,w_bishop=0,w_pawn=0;
int b_queen=0,b_rook=0,b_knight=0,b_bishop=0,b_pawn=0;

if (ply>=DMAX-4) return(0);

for (i=21;i<99;i++)
    {
    if (b[i]==WQ) w_queen++;
    if (b[i]==WR) w_rook++;
    if (b[i]==WN) w_knight++;
    if (b[i]==WB) w_bishop++;
    if (b[i]==WP) w_pawn++;
    if (b[i]==BQ) b_queen++;
    if (b[i]==BR) b_rook++;
    if (b[i]==BN) b_knight++;
    if (b[i]==BB) b_bishop++;
    if (b[i]==BP) b_pawn++;
    }

/* bare kings */
if (!w_queen&&!w_rook&&!w_knight&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#1 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WB BK */
if (!w_queen&&!w_rook&&!w_knight&&w_bishop==1&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#2 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn);
#endif
    return(EXACT);
    }
/* WK BB BK */
if (!w_queen&&!w_rook&&!w_knight&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&b_bishop==1&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#3 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WN BK */
if (!w_queen&&!w_rook&&w_knight==1&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#4 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK BN BK */
if (!w_queen&&!w_rook&&!w_knight&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&b_knight==1&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#5 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn);
#endif
    return(EXACT);
    }
/* WK WN BN BK */
if (!w_queen&&!w_rook&&w_knight==1&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&b_knight==1&&!b_bishop&&!b_pawn)
    {
#if DEBUG    
    fprintf(stdout,"#6 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WB BB BK */
if (!w_queen&&!w_rook&&!w_knight&&w_bishop==1&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&b_bishop==1&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#7 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WN WN BK */
if (!w_queen&&!w_rook&&w_knight==2&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#8 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK BN BN BK */
if (!w_queen&&!w_rook&&!w_knight&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&b_knight==2&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#9 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WN BB BK */
if (!w_queen&&!w_rook&&w_knight==1&&!w_bishop&&!w_pawn&&!b_queen&&!b_rook&&!b_knight&&b_bishop==1&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#10 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }
/* WK WB BN BK */
if (!w_queen&&!w_rook&&!w_knight&&w_bishop==1&&!w_pawn&&!b_queen&&!b_rook&&b_knight==1&&!b_bishop&&!b_pawn)
    {
#if DEBUG    
    fprintf(stdout,"#11 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(EXACT);
    }

/* WK WB vs anything is at best a draw (for CPU) */
if (!w_queen&&!w_rook&&!w_knight&&w_bishop==1&&!w_pawn)
    {
#if DEBUG
    fprintf(stdout,"#12 deaddraw returned %d\n",UPPER_BOUND);
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn);
#endif
    return(UPPER_BOUND);
    }

/* WK WN vs anything is at best a draw (for CPU) */
if (!w_queen&&!w_rook&&w_knight==1&&!w_bishop&&!w_pawn)
    {
#if DEBUG
    fprintf(stdout,"#13 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn);
#endif
    return(UPPER_BOUND);
    }

/* BK BB vs anything is at least a draw (for CPU) */
if (!b_queen&&!b_rook&&!b_knight&&b_bishop==1&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#14 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(LOWER_BOUND);
    }

/* BK BN vs anything is at least a draw (for CPU) */
if (!b_queen&&!b_rook&&b_knight==1&&!b_bishop&&!b_pawn)
    {
#if DEBUG
    fprintf(stdout,"#15 deaddraw returned 1\n");
    fprintf(stdout,"%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn); 
#endif
    return(LOWER_BOUND);
    }



/*
printf("deaddraw returned 0\n");
printf("%d%d%d%d%d%d%d%d%d%d\n",w_queen,w_rook,w_knight,w_bishop,w_pawn,b_queen,b_rook,b_knight,b_bishop,b_pawn);
*/

return(0);
}
